@php
    $user = auth()->user();
    $groups = [
        [
            'label' => 'Main',
            'items' => [
                ['title' => 'Dashboard', 'icon' => 'layout-dashboard', 'route' => 'dashboard', 'pattern' => 'dashboard', 'can' => 'dashboard.view'],
                ['title' => 'My Teaching', 'icon' => 'book-open', 'route' => 'teacher.dashboard', 'pattern' => 'teacher.dashboard', 'can' => 'marks.enter'],
            ],
        ],
        [
            'label' => 'Students',
            'items' => [
                ['title' => 'Admission Enquiry', 'icon' => 'message-circle', 'route' => 'enquiries.index', 'pattern' => 'enquiries.*', 'can' => 'enquiries.view'],
                ['title' => 'New Admission', 'icon' => 'user-plus', 'route' => 'admissions.create', 'pattern' => 'admissions.*', 'can' => 'students.create'],
                ['title' => 'All Students', 'icon' => 'users', 'route' => 'students.index', 'pattern' => 'students.index|students.show|students.edit', 'can' => 'students.view'],
                ['title' => 'Passed Out Archive', 'icon' => 'archive', 'route' => 'students.archive', 'pattern' => 'students.archive', 'can' => 'students.view'],
                ['title' => 'Promotion', 'icon' => 'trending-up', 'route' => 'promotion.index', 'pattern' => 'promotion.*', 'can' => 'students.promote'],
                ['title' => 'Session Report', 'icon' => 'file-bar-chart', 'route' => 'session-report.index', 'pattern' => 'session-report.*', 'can' => 'reports.view'],
            ],
        ],
        [
            'label' => 'Fees',
            'items' => [
                ['title' => 'Fee Structure', 'icon' => 'wallet', 'route' => 'fees.structures.index', 'pattern' => 'fees.structures.*', 'can' => 'fees.view'],
                ['title' => 'Fee Collection', 'icon' => 'receipt', 'route' => 'fees.collection.index', 'pattern' => 'fees.collection.*', 'can' => 'fees.collect'],
                ['title' => 'Quick Fee Collect', 'icon' => 'zap', 'route' => 'fees.quick.index', 'pattern' => 'fees.quick.*', 'can' => 'fees.collect'],
                ['title' => 'WhatsApp Reminder', 'icon' => 'message-circle', 'route' => 'fees.reminders.index', 'pattern' => 'fees.reminders.*', 'can' => 'fees.view'],
                ['title' => 'Fee Deletion Log', 'icon' => 'trash', 'route' => 'fees.deletion-log', 'pattern' => 'fees.deletion-log', 'can' => 'fees.view'],
            ],
        ],
        [
            'label' => 'Academics',
            'items' => [
                ['title' => 'Attendance', 'icon' => 'calendar-check', 'route' => 'attendance.index', 'pattern' => 'attendance.index', 'can' => 'attendance.view'],
                ['title' => 'Attendance Report', 'icon' => 'clipboard-list', 'route' => 'attendance.report', 'pattern' => 'attendance.report', 'can' => 'attendance.report'],
                ['title' => 'Exams', 'icon' => 'graduation-cap', 'route' => 'exams.index', 'pattern' => 'exams.index|exams.create|exams.edit|exams.show', 'can' => 'exams.view'],
                ['title' => 'Marks Entry', 'icon' => 'pencil', 'route' => 'exams.marks-entry', 'pattern' => 'exams.marks-entry|exams.marks-store', 'can' => 'marks.enter'],
                ['title' => 'Class Result', 'icon' => 'file-bar-chart', 'route' => 'exams.class-result', 'pattern' => 'exams.class-result|exams.result-sheet', 'can' => 'results.view'],
                ['title' => 'Subjects', 'icon' => 'book-open', 'route' => 'subjects.index', 'pattern' => 'subjects.*', 'can' => 'academics.view'],
                ['title' => 'Class-Subject Map', 'icon' => 'list-checks', 'route' => 'class-subjects.index', 'pattern' => 'class-subjects.*', 'can' => 'academics.view'],
                ['title' => 'Teacher Assignments', 'icon' => 'users', 'route' => 'assignments.index', 'pattern' => 'assignments.*', 'can' => 'assignments.view'],
                ['title' => 'Exam Schedule', 'icon' => 'calendar', 'route' => 'exams.schedule', 'pattern' => 'exams.schedule', 'can' => 'exams.view'],
            ],
        ],
        [
            'label' => 'Finance',
            'items' => [
                ['title' => 'Expenses', 'icon' => 'credit-card', 'route' => 'expenses.index', 'pattern' => 'expenses.*', 'can' => 'finance.view'],
                ['title' => 'All Reports', 'icon' => 'pie-chart', 'route' => 'reports.index', 'pattern' => 'reports.index', 'can' => 'reports.view'],
                ['title' => 'Income vs Expense', 'icon' => 'trending-down', 'route' => ['reports.show', 'income-expense'], 'pattern' => 'reports.show', 'can' => 'reports.view'],
            ],
        ],
        [
            'label' => 'Staff / Payroll',
            'items' => [
                ['title' => 'Staff Management', 'icon' => 'briefcase', 'route' => 'staff.index', 'pattern' => 'staff.*', 'can' => 'staff.view'],
                ['title' => 'Salary Management', 'icon' => 'banknote', 'route' => 'payroll.index', 'pattern' => 'payroll.index|payroll.generate|payroll.process|payroll.pay|payroll.slip', 'can' => 'payroll.view'],
                ['title' => 'Salary Report', 'icon' => 'file-text', 'route' => 'payroll.report', 'pattern' => 'payroll.report', 'can' => 'payroll.view'],
            ],
        ],
        [
            'label' => 'Communication',
            'items' => [
                ['title' => 'Notices', 'icon' => 'bell', 'route' => 'notices.index', 'pattern' => 'notices.*', 'can' => 'notices.view'],
            ],
        ],
        [
            'label' => 'Website',
            'items' => [
                ['title' => 'Website Dashboard', 'icon' => 'layout-dashboard', 'route' => 'website-admin.index', 'pattern' => 'website-admin.index', 'can' => 'website.view'],
                ['title' => 'Homepage Slider', 'icon' => 'eye', 'route' => 'website-admin.slider', 'pattern' => 'website-admin.slider', 'can' => 'website.view'],
                ['title' => 'Intro & Messages', 'icon' => 'message-circle', 'route' => 'website-admin.introduction', 'pattern' => 'website-admin.introduction|website-admin.administration-message|website-admin.principal-message|website-admin.president-message', 'can' => 'website.view'],
                ['title' => 'Academic Corner', 'icon' => 'graduation-cap', 'route' => 'website-admin.academic-corner', 'pattern' => 'website-admin.academic-corner', 'can' => 'website.view'],
                ['title' => 'News & Events', 'icon' => 'file-text', 'route' => 'website-admin.news', 'pattern' => 'website-admin.news|website-admin.events', 'can' => 'website.view'],
                ['title' => 'Gallery', 'icon' => 'eye', 'route' => 'website-admin.gallery', 'pattern' => 'website-admin.gallery', 'can' => 'website.view'],
                ['title' => 'Pages & Downloads', 'icon' => 'book-open', 'route' => 'website-admin.pages', 'pattern' => 'website-admin.pages|website-admin.downloads', 'can' => 'website.view'],
                ['title' => 'Faculty Profiles', 'icon' => 'users', 'route' => 'website-admin.faculty', 'pattern' => 'website-admin.faculty', 'can' => 'website.view'],
                ['title' => 'Design & Logo', 'icon' => 'settings', 'route' => 'website-admin.design', 'pattern' => 'website-admin.design', 'can' => 'website.manage'],
                ['title' => 'Menus', 'icon' => 'menu', 'route' => 'website-menus.index', 'pattern' => 'website-menus.*', 'can' => 'website.menus'],
                ['title' => 'Media Library', 'icon' => 'eye', 'route' => 'media.index', 'pattern' => 'media.*', 'can' => 'website.media'],
                ['title' => 'Contact Messages', 'icon' => 'mail', 'route' => 'messages.index', 'pattern' => 'messages.*', 'can' => 'website.view'],
            ],
        ],
        [
            'label' => 'Admin',
            'items' => [
                ['title' => 'Admin Settings', 'icon' => 'user-cog', 'route' => 'admin.index', 'pattern' => 'admin.*|sessions.*|classes.*|sections.*|users.*|roles.*|audit.*|portal-accounts.*', 'can' => 'settings.view'],
                ['title' => 'Portal Accounts', 'icon' => 'user-check', 'route' => 'portal-accounts.index', 'pattern' => 'portal-accounts.*', 'can' => 'portals.manage'],
                ['title' => 'Settings', 'icon' => 'settings', 'route' => 'settings.index', 'pattern' => 'settings.*', 'can' => 'settings.view'],
            ],
        ],
    ];
@endphp

<aside class="sidebar" :class="sidebarOpen && 'open'" aria-label="Main navigation">
    <div class="sidebar-brand">
        <div class="brand-mark"><x-icon name="graduation-cap" :size="23" /></div>
        <div>
            <div class="brand-name">{{ $schoolSettings['name'] ?? 'EduSphere' }}</div>
            <div class="brand-sub">School Management</div>
        </div>
        <button type="button" class="btn-icon" style="margin-left:auto" @click="sidebarOpen = false" aria-label="Close navigation">
            <x-icon name="x" :size="17" />
        </button>
    </div>

    <div class="sidebar-scroll">
        @foreach ($groups as $group)
            @php
                $visible = collect($group['items'])->filter(fn ($item) => $user?->can($item['can']))->count();
            @endphp
            @if ($visible)
                <div class="nav-section">
                    <div class="nav-label">{{ $group['label'] }}</div>
                    @foreach ($group['items'] as $item)
                        @can($item['can'])
                            @php
                                $url = is_array($item['route']) ? route($item['route'][0], $item['route'][1]) : route($item['route']);
                                $active = collect(explode('|', $item['pattern']))->contains(fn ($pattern) => request()->routeIs($pattern));
                            @endphp
                            <a href="{{ $url }}" class="sidebar-link {{ $active ? 'active' : '' }}">
                                <x-icon :name="$item['icon']" :size="17" class="nav-icon" />
                                <span>{{ $item['title'] }}</span>
                            </a>
                        @endcan
                    @endforeach
                </div>
            @endif
        @endforeach

        <div class="nav-section">
            <div class="nav-label">Account</div>
            <a href="{{ route('password.change') }}" class="sidebar-link {{ request()->routeIs('password.*') ? 'active' : '' }}">
                <x-icon name="key" :size="17" class="nav-icon" />
                <span>Password Change</span>
            </a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="sidebar-link" style="width:100%;border:0;background:transparent;text-align:left">
                    <x-icon name="log-out" :size="17" class="nav-icon" />
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <div class="sidebar-footer">
        <div class="session-chip">
            <span class="dot"></span>
            <div>
                <div class="session-chip-label">Academic Session</div>
                <div class="session-chip-value">{{ $currentSession?->name ?? 'Not configured' }}</div>
            </div>
            <x-icon name="chevron-right" :size="14" style="margin-left:auto;color:#7c6f9e" />
        </div>
    </div>
</aside>
