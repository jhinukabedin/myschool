@php
    $portalUser = auth()->user();
    $portalRole = $portalUser?->role?->slug;
    $portalName = match ($portalRole) {
        'student' => 'Student Portal',
        'parent' => 'Parent Portal',
        'teacher' => 'Teacher Portal',
        default => 'School Portal',
    };
    $portalNav = match ($portalRole) {
        'student' => [
            ['label' => 'Dashboard', 'route' => 'student.dashboard', 'active' => 'student.dashboard'],
            ['label' => 'Results', 'route' => 'student.results', 'active' => 'student.results*'],
            ['label' => 'Fees & Payments', 'route' => 'student.fees', 'active' => 'student.fees|student.payments.*'],
            ['label' => 'Attendance', 'route' => 'student.attendance', 'active' => 'student.attendance'],
            ['label' => 'Downloads', 'route' => 'student.downloads', 'active' => 'student.downloads'],
            ['label' => 'My Profile', 'route' => 'student.profile', 'active' => 'student.profile'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        'parent' => [
            ['label' => 'Dashboard', 'route' => 'parent.dashboard', 'active' => 'parent.dashboard'],
            ['label' => 'My Profile', 'route' => 'parent.profile', 'active' => 'parent.profile'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        'teacher' => [
            ['label' => 'My Teaching', 'route' => 'teacher.dashboard', 'active' => 'teacher.dashboard'],
            ['label' => 'Marks Entry', 'route' => 'exams.marks-entry', 'active' => 'exams.marks-entry'],
            ['label' => 'Attendance', 'route' => 'attendance.index', 'active' => 'attendance.index'],
            ['label' => 'Exam Schedule', 'route' => 'exams.schedule', 'active' => 'exams.schedule'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        default => [],
    };
@endphp
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', $portalName) · {{ school_setting('website_name_en', 'Adarsha High School') }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('portal/style.css') }}">
    @stack('head')
</head>
<body>
<a class="skip-link" href="#portal-main">Skip to content</a>
<header class="portal-header">
    <div class="portal-wrap header-inner">
        <a class="portal-brand" href="{{ route($portalUser?->homeRouteName() ?? 'website.home') }}">
            <span class="brand-mark">{{ school_setting('website_logo_mark', 'HS') }}</span>
            <span>
                <strong>{{ school_setting('website_name_bn', 'আদর্শ উচ্চ বিদ্যালয়') }}</strong>
                <small>{{ $portalName }}</small>
            </span>
        </a>
        <div class="header-meta">
            <span class="session-pill">Session {{ current_session()?->name ?? '—' }}</span>
            <span class="user-pill">{{ $portalUser?->name }}<small>{{ $portalName }}</small></span>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn-ghost">Sign out</button>
            </form>
        </div>
    </div>
</header>
<nav class="portal-nav" aria-label="Portal navigation">
    <div class="portal-wrap nav-inner">
        @foreach ($portalNav as $item)
            <a href="{{ route($item['route']) }}" @class(['nav-link', 'active' => request()->routeIs($item['active'])])>{{ $item['label'] }}</a>
        @endforeach
        <a href="{{ route('website.home') }}" class="nav-link nav-link-external">School website ↗</a>
    </div>
</nav>

<main id="portal-main" class="portal-wrap portal-main">
    @if (session('success'))
        <div class="alert alert-success" role="status">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert alert-error" role="alert">{{ session('error') }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-error" role="alert">
            <strong>Please correct the following:</strong>
            <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif

    @yield('content')
</main>

<footer class="portal-footer">
    <div class="portal-wrap footer-inner">
        <span>© {{ now()->format('Y') }} {{ school_setting('school_name', 'School') }}. All rights reserved.</span>
        <a href="{{ route('website.privacy') }}">Privacy</a>
    </div>
</footer>
@stack('scripts')
</body>
</html>
