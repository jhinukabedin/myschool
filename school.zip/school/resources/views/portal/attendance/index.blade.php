@extends('layouts.portal')

@section('title', 'Attendance')

@section('content')
    <div class="page-head">
        <div>
            <p class="eyebrow">Daily attendance</p>
            <h1>{{ $portalRole === 'parent' ? $student->full_name.'\'s Attendance' : 'My Attendance' }}</h1>
            <p>Attendance marked by teachers for {{ $session?->name ?? 'the current session' }}. Contact the class teacher if a record looks wrong.</p>
        </div>
        @if (isset($children) && $children->count() > 1)
            <div class="selector-form">
                <div class="field">
                    <label for="child-switch">Child</label>
                    <select id="child-switch" onchange="if(this.value) window.location.href=this.value">
                        @foreach ($children as $childOption)
                            <option value="{{ route('parent.attendance.index', $childOption) }}" @selected($childOption->id === $student->id)>{{ $childOption->full_name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        @endif
    </div>

    <div class="metric-grid">
        <div class="card stat"><div class="stat-label">Attendance rate</div><div class="stat-value">{{ number_format($attendance['percentage'], 1) }}%</div><div class="stat-meta">Present or late</div></div>
        <div class="card stat"><div class="stat-label">Present</div><div class="stat-value" style="color:var(--success)">{{ $attendance['present'] }}</div><div class="stat-meta">{{ $attendance['records'] }} marked days</div></div>
        <div class="card stat"><div class="stat-label">Absent</div><div class="stat-value" style="color:var(--danger)">{{ $attendance['absent'] }}</div><div class="stat-meta">Unexcused absence</div></div>
        <div class="card stat"><div class="stat-label">Late / excused</div><div class="stat-value">{{ $attendance['late'] }} / {{ $attendance['excused'] }}</div><div class="stat-meta">Recorded separately</div></div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="receipt-row" style="margin-bottom:8px"><strong>Overall attendance</strong><span class="mono">{{ number_format($attendance['percentage'], 1) }}%</span></div>
            <div class="progress"><span style="width: {{ min(100, $attendance['percentage']) }}%"></span></div>
            <p class="small muted" style="margin:9px 0 0">
                @if ($enrollment)
                    {{ $enrollment->class?->name }} · Section {{ $enrollment->section?->name ?? '—' }} · Roll {{ $enrollment->roll_no ?? '—' }}
                @else
                    No current enrollment is recorded.
                @endif
            </p>
        </div>
    </div>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>Recent attendance</h2><p>The latest 10 marked days</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Date</th><th>Class</th><th>Status</th><th>Note</th></tr></thead>
                <tbody>
                    @forelse ($attendance['recent'] as $record)
                        <tr>
                            <td class="mono">{{ $record->attendance_date?->format('d M Y') }}</td>
                            <td>{{ $record->class?->name }}</td>
                            <td>
                                <span class="badge {{ $record->status === 'present' ? 'badge-success' : ($record->status === 'absent' ? 'badge-danger' : 'badge-warning') }}">{{ ucfirst($record->status) }}</span>
                            </td>
                            <td class="muted">{{ $record->note ?? '—' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="empty">No attendance has been marked.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>
@endsection
