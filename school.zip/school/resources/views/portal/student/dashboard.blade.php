@extends('layouts.portal')

@section('title', 'Student Dashboard')

@section('content')
    <div class="page-head">
        <div>
            <p class="eyebrow">Student portal</p>
            <h1>Welcome, {{ $student->first_name }}</h1>
            <p>Your academic, attendance and fee information for {{ $session?->name ?? 'the current session' }}.</p>
        </div>
        <a class="btn btn-secondary" href="{{ route('student.results') }}">View all results</a>
    </div>

    <div class="card profile-strip" style="margin-bottom:18px">
        <div class="avatar">
            @if ($student->photo_url)
                <img src="{{ $student->photo_url }}" alt="{{ $student->full_name }}">
            @else
                {{ Str::upper(Str::substr($student->first_name, 0, 1).Str::substr($student->last_name, 0, 1)) }}
            @endif
        </div>
        <div>
            <h2>{{ $student->full_name }}</h2>
            <div class="chips">
                <span class="chip">{{ $student->admission_no }}</span>
                @if ($enrollment)
                    <span class="chip">{{ $enrollment->class?->name }}</span>
                    <span class="chip">Section {{ $enrollment->section?->name ?? '—' }}</span>
                    <span class="chip">Roll {{ $enrollment->roll_no ?? '—' }}</span>
                @endif
                <span class="chip">{{ $session?->name ?? 'No session' }}</span>
                <span class="chip chip-success">Active</span>
            </div>
        </div>
        <div class="chips">
            <a class="btn btn-secondary btn-sm" href="{{ route('student.profile') }}">My profile</a>
        </div>
    </div>

    <div class="metric-grid">
        <div class="card stat"><div class="stat-label">Attendance</div><div class="stat-value">{{ number_format($attendance['percentage'], 1) }}%</div><div class="stat-meta">{{ $attendance['present'] + $attendance['late'] }} of {{ $attendance['records'] }} marked days</div></div>
        <div class="card stat"><div class="stat-label">Fees assigned</div><div class="stat-value">{{ money($fees['total_charged']) }}</div><div class="stat-meta">{{ $fees['assignments']->count() }} fee row(s)</div></div>
        <div class="card stat"><div class="stat-label">Paid</div><div class="stat-value" style="color:var(--success)">{{ money($fees['total_paid']) }}</div><div class="stat-meta">{{ $fees['payments']->where('status', 'completed')->count() }} completed payment(s)</div></div>
        <div class="card stat"><div class="stat-label">Outstanding</div><div class="stat-value" style="color:{{ $fees['balance'] > 0 ? 'var(--danger)' : 'var(--success)' }}">{{ money($fees['balance']) }}</div><div class="stat-meta">{{ $fees['overdue'] > 0 ? money($fees['overdue']).' overdue' : 'Nothing overdue' }}</div></div>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head">
                <div><h2>Published results</h2><p>Only results published by the school appear here.</p></div>
                <a class="btn btn-secondary btn-sm" href="{{ route('student.results') }}">All results</a>
            </div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Examination</th><th class="num">GPA</th><th>Grade</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                        @forelse ($results as $row)
                            <tr>
                                <td class="title-cell"><strong>{{ $row['exam']->name }}</strong><span>{{ $row['published_at']?->format('d M Y') }}</span></td>
                                <td class="num mono">{{ number_format($row['result']['gpa'], 2) }}</td>
                                <td>{{ $row['result']['grade'] }}</td>
                                <td><span class="badge {{ $row['result']['result'] === 'Pass' ? 'badge-success' : 'badge-danger' }}">{{ $row['result']['result'] }}</span></td>
                                <td><a class="btn btn-secondary btn-sm" href="{{ route('student.results.show', $row['exam']) }}">Open</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="empty">No published results are available yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Attendance snapshot</h2><p>Recent attendance in the current session.</p></div><a class="btn btn-secondary btn-sm" href="{{ route('student.attendance') }}">Details</a></div>
            <div class="card-body">
                <div class="progress" aria-label="Attendance percentage"><span style="width: {{ min(100, $attendance['percentage']) }}%"></span></div>
                <div class="chips" style="margin-top:12px">
                    <span class="chip chip-success">Present {{ $attendance['present'] }}</span>
                    <span class="chip chip-danger">Absent {{ $attendance['absent'] }}</span>
                    <span class="chip chip-warning">Late {{ $attendance['late'] }}</span>
                    <span class="chip">Excused {{ $attendance['excused'] }}</span>
                </div>
                <div class="list" style="margin-top:12px">
                    @forelse ($attendance['recent'] as $record)
                        <div class="list-item">
                            <div><strong>{{ $record->attendance_date?->format('d M Y') }}</strong><small>{{ $record->class?->name }}</small></div>
                            <span class="badge {{ $record->status === 'present' ? 'badge-success' : ($record->status === 'absent' ? 'badge-danger' : 'badge-warning') }}">{{ ucfirst($record->status) }}</span>
                        </div>
                    @empty
                        <div class="empty">No attendance has been marked yet.</div>
                    @endforelse
                </div>
            </div>
        </section>
    </div>

    <div class="grid grid-2" style="margin-top:18px">
        <section class="card">
            <div class="card-head"><div><h2>Fee ledger</h2><p>Assigned fees, discounts and balances.</p></div><a class="btn btn-secondary btn-sm" href="{{ route('student.fees') }}">Manage fees</a></div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Fee head</th><th>Period</th><th class="num">Net</th><th class="num">Paid</th><th class="num">Balance</th></tr></thead>
                    <tbody>
                        @forelse ($fees['assignments']->take(6) as $row)
                            <tr>
                                <td>{{ $row->category?->name ?? 'Fee' }}</td>
                                <td class="mono">{{ $row->period ?? 'One-time' }}</td>
                                <td class="num mono">{{ money($row->net_amount) }}</td>
                                <td class="num mono">{{ money($row->paid_amount) }}</td>
                                <td class="num mono">{{ money($row->balance) }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="empty">No fees have been assigned.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Notices</h2><p>Published school announcements.</p></div></div>
            <div class="list">
                @forelse ($notices as $notice)
                    <div class="list-item">
                        <div><strong>{{ $notice->title }}</strong><small>{{ Str::limit(strip_tags($notice->body), 90) }}</small></div>
                        <span class="notice-date">{{ $notice->publish_at?->format('d') ?? $notice->created_at?->format('d') }}<br>{{ $notice->publish_at?->format('M') ?? $notice->created_at?->format('M') }}</span>
                    </div>
                @empty
                    <div class="empty">No notices have been published.</div>
                @endforelse
            </div>
        </section>
    </div>

    <div class="grid grid-2" style="margin-top:18px">
        <section class="card">
            <div class="card-head"><div><h2>Upcoming examinations</h2><p>Published exam schedule for your class.</p></div></div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Subject</th><th>Examination</th><th>Date</th></tr></thead>
                    <tbody>
                        @forelse ($exams as $paper)
                            <tr><td>{{ $paper->subject?->name }}</td><td>{{ $paper->examination?->name }}</td><td class="mono">{{ $paper->exam_date?->format('d M Y') ?? 'Not scheduled' }}{{ $paper->start_time ? ' · '.substr($paper->start_time, 0, 5) : '' }}</td></tr>
                        @empty
                            <tr><td colspan="3" class="empty">No published examination schedule is available.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Downloads</h2><p>Files published for students.</p></div><a class="btn btn-secondary btn-sm" href="{{ route('student.downloads') }}">All files</a></div>
            <div class="list">
                @forelse ($downloads as $download)
                    <div class="list-item">
                        <div><strong>{{ $download->title }}</strong><small>{{ $download->excerpt ?: $download->category }}</small></div>
                        @if ($download->file_url)<a class="btn btn-secondary btn-sm" href="{{ $download->file_url }}" target="_blank" rel="noopener">Download</a>@endif
                    </div>
                @empty
                    <div class="empty">No files are available.</div>
                @endforelse
            </div>
        </section>
    </div>
@endsection
