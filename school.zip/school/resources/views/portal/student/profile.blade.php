@extends('layouts.portal')

@section('title', 'My Profile')

@section('content')
    <div class="page-head">
        <div>
            <p class="eyebrow">Student portal</p>
            <h1>My Profile</h1>
            <p>Your admission details and family contact information. Ask the school office if anything needs correction.</p>
        </div>
        <a class="btn btn-secondary" href="{{ route('student.dashboard') }}">Back to dashboard</a>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head"><div><h2>Personal information</h2><p>Official school record</p></div></div>
            <div class="card-body">
                <div class="grid grid-2">
                    <div><div class="small muted">Full name</div><strong>{{ $student->full_name }}</strong></div>
                    <div><div class="small muted">Student ID</div><strong class="mono">{{ $student->student_code ?? '—' }}</strong></div>
                    <div><div class="small muted">Admission no</div><strong class="mono">{{ $student->admission_no }}</strong></div>
                    <div><div class="small muted">Date of birth</div><strong>{{ $student->date_of_birth?->format('d M Y') ?? '—' }}</strong></div>
                    <div><div class="small muted">Gender</div><strong>{{ ucfirst($student->gender ?? '—') }}</strong></div>
                    <div><div class="small muted">Blood group</div><strong>{{ $student->blood_group ?? '—' }}</strong></div>
                    <div><div class="small muted">Religion</div><strong>{{ $student->religion ?? '—' }}</strong></div>
                    <div><div class="small muted">Phone</div><strong>{{ $student->phone ?? '—' }}</strong></div>
                    <div><div class="small muted">Email</div><strong>{{ $student->email ?? '—' }}</strong></div>
                    <div class="field-span"><div class="small muted">Address</div><strong>{{ collect([$student->address, $student->city, $student->state, $student->postal_code])->filter()->implode(', ') ?: '—' }}</strong></div>
                    <div><div class="small muted">Admission date</div><strong>{{ $student->admission_date?->format('d M Y') ?? '—' }}</strong></div>
                    <div><div class="small muted">Status</div><span class="badge badge-success">{{ $student->status_label }}</span></div>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Guardians</h2><p>Primary emergency contacts</p></div></div>
            <div class="list">
                @forelse ($student->guardians as $guardian)
                    <div class="list-item">
                        <div>
                            <strong>{{ $guardian->name }}</strong>
                            <small>{{ $guardian->relation ?? 'Guardian' }}{{ $guardian->phone ? ' · '.$guardian->phone : '' }}{{ $guardian->email ? ' · '.$guardian->email : '' }}</small>
                            @if ($guardian->address)<small>{{ $guardian->address }}</small>@endif
                        </div>
                        @if ($guardian->is_primary)<span class="badge badge-info">Primary</span>@endif
                    </div>
                @empty
                    <div class="empty">No guardian information is recorded.</div>
                @endforelse
            </div>
        </section>
    </div>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>Enrollment history</h2><p>Classes and sessions recorded by the school</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Session</th><th>Class</th><th>Section</th><th>Roll</th><th>Status</th></tr></thead>
                <tbody>
                    @forelse ($student->enrollments->sortByDesc('academic_session_id') as $enrollment)
                        <tr>
                            <td>{{ $enrollment->academicSession?->name }}</td>
                            <td>{{ $enrollment->class?->name }}</td>
                            <td>{{ $enrollment->section?->name ?? '—' }}</td>
                            <td class="mono">{{ $enrollment->roll_no ?? '—' }}</td>
                            <td><span class="badge {{ $enrollment->status === 'active' ? 'badge-success' : 'badge-warning' }}">{{ ucfirst($enrollment->status) }}</span></td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="empty">No enrollment records are available.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>
@endsection
