@extends('layouts.portal')

@section('title', 'Downloads')

@section('content')
    <div class="page-head">
        <div>
            <p class="eyebrow">Resources</p>
            <h1>Downloads</h1>
            <p>Syllabus, forms and other files published by the school for students and guardians.</p>
        </div>
    </div>

    <div class="grid grid-2">
        @forelse ($downloads as $download)
            <article class="card">
                <div class="card-body">
                    <div class="chips" style="margin-bottom:8px">
                        <span class="badge badge-info">{{ $download->category ?: 'Resource' }}</span>
                        @if ($download->published_at)<span class="badge">{{ $download->published_at->format('d M Y') }}</span>@endif
                    </div>
                    <h2 style="margin:0 0 6px;font-size:17px">{{ $download->title }}</h2>
                    <p class="muted" style="margin:0 0 14px">{{ $download->excerpt ?: 'Published school document.' }}</p>
                    @if ($download->file_url)
                        <a class="btn btn-primary" href="{{ $download->file_url }}" target="_blank" rel="noopener">Download file</a>
                    @else
                        <span class="badge badge-warning">File unavailable</span>
                    @endif
                </div>
            </article>
        @empty
            <div class="card" style="grid-column:1/-1"><div class="empty">No downloads have been published.</div></div>
        @endforelse
    </div>
@endsection
