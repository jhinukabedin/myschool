@extends('layouts.public')

@section('title', 'একাডেমিক ক্যালেন্ডার')

@section('content')
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / শিক্ষাক্রম / ক্যালেন্ডার</div><h1>একাডেমিক ক্যালেন্ডার</h1><p>{{ $session?->name ?? 'চলমান' }} সেশনের পরীক্ষা ও অনুষ্ঠান</p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <h2>পরীক্ষার সময়সূচি</h2>
            <div class="timeline">
                @forelse ($exams as $exam)
                    <div class="timeline-item">
                        <small>{{ $exam->start_date?->format('d M Y') }}@if ($exam->end_date) – {{ $exam->end_date->format('d M Y') }}@endif</small>
                        <b>{{ $exam->name }}</b>
                        <p style="margin:4px 0 0">শ্রেণি: {{ $exam->subjects->pluck('class_id')->unique()->count() }} · অবস্থা: {{ ucfirst($exam->status) }}</p>
                    </div>
                @empty
                    <p>এই সেশনে কোনো পরীক্ষার সময়সূচি প্রকাশিত হয়নি।</p>
                @endforelse
            </div>

            <h2 style="margin-top:24px">অনুষ্ঠান</h2>
            <div class="timeline">
                @forelse ($events as $event)
                    <div class="timeline-item">
                        <small>{{ $event->published_at?->format('d M Y') }}</small>
                        <b>{{ $event->title }}</b>
                        <p style="margin:4px 0 0">{{ $event->excerpt ?: Str::limit(strip_tags($event->body), 120) }}</p>
                    </div>
                @empty
                    <p>বর্তমানে কোনো প্রকাশিত অনুষ্ঠান নেই।</p>
                @endforelse
            </div>
        </article>
        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">দ্রুত লিংক</h3>
                <a href="{{ route('website.notices') }}" style="display:block;padding:6px 0">নোটিশ বোর্ড</a>
                <a href="{{ route('website.events') }}" style="display:block;padding:6px 0">ইভেন্ট</a>
                <a href="{{ route('website.academics') }}" style="display:block;padding:6px 0">ক্লাস ও বিষয়</a>
                <a href="{{ route('website.downloads') }}" style="display:block;padding:6px 0">ডাউনলোড</a>
            </div>
        </aside>
    </div></section>
@endsection
