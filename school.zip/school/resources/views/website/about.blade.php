@extends('layouts.public')

@section('title', 'বিদ্যালয় পরিচিতি')

@section('content')
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / পরিচিতি</div><h1>বিদ্যালয় পরিচিতি</h1><p>{{ $siteNameBn }} · {{ $siteNameEn }}</p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <h2 id="history">{{ $introduction?->title ?: 'আমাদের বিদ্যালয়' }}</h2>
            @if ($introduction)
                @if ($introduction->image_url)
                    <img class="about-photo" src="{{ $introduction->image_url }}" alt="{{ $introduction->title }}">
                @endif
                @if ($introduction->excerpt)<p class="lead-text">{{ $introduction->excerpt }}</p>@endif
                <div>{!! $introduction->body_html !!}</div>
            @endif
            @if ($page)
                <div>{!! $page->body_html !!}</div>
            @elseif (! $introduction)
                <p>{{ $siteNameBn }} একটি আধুনিক শিক্ষা প্রতিষ্ঠান, যেখানে জ্ঞান, শৃঙ্খলা ও নৈতিকতার সমন্বয়ে শিক্ষার্থীদের ভবিষ্যতের জন্য প্রস্তুত করা হয়। অভিজ্ঞ শিক্ষকমণ্ডলী, সুশৃঙ্খল একাডেমিক কার্যক্রম এবং সহশিক্ষা কার্যক্রমের মাধ্যমে শিক্ষার্থীদের মেধা ও মানবিক মূল্যবোধের বিকাশে আমরা কাজ করি।</p>
                <p>আমাদের লক্ষ্য একটি নিরাপদ, আনন্দময় ও অন্তর্ভুক্তিমূলক শিক্ষার পরিবেশ তৈরি করা, যেখানে প্রতিটি শিক্ষার্থী নিজের সর্বোচ্চ সম্ভাবনায় পৌঁছাতে পারে।</p>
            @endif

            <h3 id="mission">লক্ষ্য ও উদ্দেশ্য</h3>
            <ul>
                <li>মানসম্মত শিক্ষা নিশ্চিত করে শিক্ষার্থীদের একাডেমিক ভিত্তি মজবুত করা।</li>
                <li>নৈতিকতা, শৃঙ্খলা, দায়িত্ববোধ ও নেতৃত্বের গুণাবলি বিকাশ করা।</li>
                <li>সৃজনশীলতা, বিজ্ঞানমনস্কতা ও প্রযুক্তিগত দক্ষতা উৎসাহিত করা।</li>
                <li>সহশিক্ষা ও সাংস্কৃতিক কার্যক্রমের মাধ্যমে সর্বাঙ্গীণ বিকাশ নিশ্চিত করা।</li>
            </ul>

            <h3 id="rules">নিয়মাবলি</h3>
            <ul>
                <li>প্রতিদিন নির্ধারিত সময়ে বিদ্যালয়ে উপস্থিত থাকা বাধ্যতামূলক।</li>
                <li>বিদ্যালয়ের নির্ধারিত পোশাক পরিধান করতে হবে।</li>
                <li>শিক্ষক ও সহপাঠীদের প্রতি সম্মানজনক আচরণ করতে হবে।</li>
                <li>মোবাইল ফোন ও অন্যান্য ইলেকট্রনিক ডিভাইস ব্যবহারে বিদ্যালয়ের নীতিমালা প্রযোজ্য।</li>
            </ul>

            <h3 id="facilities">সুবিধাসমূহ</h3>
            <ul>
                <li>আলোকিত ও বায়ুচলাচলযুক্ত শ্রেণিকক্ষ।</li>
                <li>গ্রন্থাগার ও পাঠকক্ষ।</li>
                <li>বিজ্ঞান ও কম্পিউটার ল্যাব।</li>
                <li>খেলাধুলা ও সাংস্কৃতিক কার্যক্রমের ব্যবস্থা।</li>
            </ul>

            <h3>ক্লাসসমূহ</h3>
            <p>{{ $classes->count() }}টি ক্লাসে শিক্ষা কার্যক্রম পরিচালিত হয়। <a href="{{ route('website.academics') }}">ক্লাস ও বিষয়সমূহ দেখুন →</a></p>
        </article>

        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">দ্রুত লিংক</h3>
                <a href="{{ route('website.administration-message') }}" style="display:block;padding:7px 0">প্রশাসনের বাণী</a>
                <a href="{{ route('website.principal-message') }}" style="display:block;padding:7px 0">প্রধান শিক্ষকের বাণী</a>
                <a href="{{ route('website.president-message') }}" style="display:block;padding:7px 0">সভাপতির বাণী</a>
                <a href="{{ route('website.faculty') }}" style="display:block;padding:7px 0">শিক্ষকবৃন্দ</a>
                <a href="{{ route('website.academics') }}" style="display:block;padding:7px 0">একাডেমিক কার্যক্রম</a>
                <a href="{{ route('website.admission') }}" style="display:block;padding:7px 0">ভর্তি তথ্য</a>
                <a href="{{ route('website.contact') }}" style="display:block;padding:7px 0">যোগাযোগ</a>
            </div>
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">যোগাযোগ</h3>
                @if ($siteAddress)<p>{{ $siteAddress }}</p>@endif
                @if ($sitePhone)<p>ফোন: {{ $sitePhone }}</p>@endif
                @if ($siteEmail)<p>ইমেইল: {{ $siteEmail }}</p>@endif
            </div>
        </aside>
    </div></section>
@endsection

@push('head')
    <style>
        .about-photo { width: 100%; max-height: 360px; object-fit: cover; border-radius: 14px; margin: 6px 0 20px; }
        .article .lead-text { font-size: 16px; color: var(--navy); font-weight: 600; }
    </style>
@endpush
