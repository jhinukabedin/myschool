@php
    $adminTabs = [
        ['label' => 'Overview', 'route' => 'admin.index', 'active' => 'admin.index', 'can' => 'settings.view'],
        ['label' => 'Sessions', 'route' => 'sessions.index', 'active' => 'sessions.*', 'can' => 'academics.manage'],
        ['label' => 'Classes', 'route' => 'classes.index', 'active' => 'classes.*', 'can' => 'academics.manage'],
        ['label' => 'Sections', 'route' => 'sections.index', 'active' => 'sections.*', 'can' => 'academics.manage'],
        ['label' => 'Users', 'route' => 'users.index', 'active' => 'users.*', 'can' => 'users.manage'],
        ['label' => 'Roles', 'route' => 'roles.index', 'active' => 'roles.*', 'can' => 'users.manage'],
        ['label' => 'Portal Accounts', 'route' => 'portal-accounts.index', 'active' => 'portal-accounts.*', 'can' => 'portals.manage'],
        ['label' => 'Audit Log', 'route' => 'audit.index', 'active' => 'audit.*', 'can' => 'audit.view'],
        ['label' => 'Website', 'route' => 'website-admin.index', 'active' => 'website-admin.*|website-content.*', 'can' => 'website.view'],
        ['label' => 'Messages', 'route' => 'messages.index', 'active' => 'messages.*', 'can' => 'website.view'],
        ['label' => 'Settings', 'route' => 'settings.index', 'active' => 'settings.*', 'can' => 'settings.view'],
    ];
@endphp

<div class="tabs" style="margin-bottom:16px;border:1px solid var(--line);border-radius:12px;background:var(--surface)">
    @foreach ($adminTabs as $tab)
        @can($tab['can'])
            <a href="{{ route($tab['route']) }}" class="tab {{ request()->routeIs($tab['active']) ? 'active' : '' }}">{{ $tab['label'] }}</a>
        @endcan
    @endforeach
</div>
