@extends('layouts.app')

@section('title', $content->exists ? 'Edit Website Content' : 'New Website Content')

@php
    $formTitle = $section['title'] ?? ($content->exists ? 'Edit Website Content' : 'New Website Content');
@endphp

@push('head')
    <style>
        .rich-toolbar { display: flex; flex-wrap: wrap; gap: 4px; padding: 8px; border: 1px solid #cfd8e5; border-bottom: 0; border-radius: 10px 10px 0 0; background: #eef2f7; }
        .rich-toolbar button { min-width: 32px; min-height: 30px; padding: 4px 8px; border: 1px solid #c7d2e1; background: #fff !important; color: #1f2a44 !important; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600; line-height: 1.2; }
        .rich-toolbar button:hover, .rich-toolbar button:focus-visible { background: #dce7f5 !important; color: #102f50 !important; border-color: #8ea9c6; outline: 2px solid #385d79; outline-offset: 1px; }
        .rich-editor { min-height: 240px; max-height: 620px; overflow: auto; padding: 16px; border: 1px solid var(--border); border-radius: 0 0 10px 10px; background: #fff; line-height: 1.7; }
        .rich-editor:focus { outline: 2px solid var(--primary, #385d79); outline-offset: 1px; }
        .rich-editor h2 { font-size: 24px; margin: 18px 0 8px; }
        .rich-editor h3 { font-size: 19px; margin: 16px 0 8px; }
        .rich-editor blockquote { border-left: 4px solid #cbd5e1; margin-left: 0; padding-left: 14px; color: #475467; }
        .rich-editor img { max-width: 100%; height: auto; border-radius: 8px; }
        .source-box { margin-top: 10px; }
        .source-box summary { cursor: pointer; font-size: 12px; color: #667085; }
        .source-box textarea { width: 100%; min-height: 180px; margin-top: 8px; font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 12px; }
    </style>
@endpush

@section('content')
    <x-page-header eyebrow="Website content" :title="$content->exists ? 'Edit: '.$formTitle : 'New: '.$formTitle"
        subtitle="Published items appear on the public website immediately. Drafts and archived items stay private. Rich text is sanitized on the server.">
        <x-slot:actions>
            @if ($content->exists && $content->public_url && $content->status === 'published')
                <x-button :href="$content->public_url" variant="secondary" icon="external-link" target="_blank">Preview</x-button>
            @endif
            <x-button :href="route('website-content.index')" variant="secondary" icon="arrow-left">Content library</x-button>
        </x-slot:actions>
    </x-page-header>

    @include('admin._nav')
    @include('admin.website._nav')

    <form id="content-form" method="POST" action="{{ $content->exists ? route('website-content.update', $content) : route('website-content.store') }}" enctype="multipart/form-data">
        @csrf
        @if ($content->exists) @method('PUT') @endif

        <div class="grid-2">
            <div>
                <div class="card">
                    <div class="card-header"><div><h3 class="card-title">Content</h3><p class="card-sub">Type, title, body and publishing state</p></div></div>
                    <div class="form-section">
                        <div class="form-grid">
                            <x-select name="type" label="Content type" :options="$types" :selected="$content->type" required />
                            <x-select name="status" label="Status" :options="['draft' => 'Draft', 'published' => 'Published', 'archived' => 'Archived']" :selected="$content->status" required />
                            <div class="span-2">
                                <x-input name="title" label="Title" :value="$content->title" required maxlength="200" />
                            </div>
                            <x-input name="slug" label="Slug" :value="$content->slug" help="Leave blank to generate from the title. Used by news and custom pages." />
                            <x-input name="category" label="Category / kicker" :value="$content->category" placeholder="e.g. Notice, Sports, Academic" />
                            <x-input name="link_url" label="Button / card link" :value="$content->link_url" placeholder="/academics or https://example.com" help="Used by homepage slides and academic cards. Relative paths are allowed." />
                            <x-input name="button_label" label="Button label" :value="$content->button_label" placeholder="বিস্তারিত দেখুন" />
                            <div class="span-2">
                                <x-textarea name="excerpt" label="Short summary" rows="2" :value="$content->excerpt" maxlength="500" help="For a message section this can hold the person's role or short introduction." />
                            </div>
                            <div class="span-2">
                                <label class="field-label">Body</label>
                                <input type="hidden" name="body_format" value="html">
                                <div class="rich-toolbar" role="toolbar" aria-label="Formatting">
                                    <button type="button" data-command="bold" title="Bold"><strong>B</strong></button>
                                    <button type="button" data-command="italic" title="Italic"><em>I</em></button>
                                    <button type="button" data-command="underline" title="Underline"><u>U</u></button>
                                    <button type="button" data-block="p" title="Paragraph">¶</button>
                                    <button type="button" data-block="h2" title="Heading 2">H2</button>
                                    <button type="button" data-block="h3" title="Heading 3">H3</button>
                                    <button type="button" data-command="insertUnorderedList" title="Bulleted list">• List</button>
                                    <button type="button" data-command="insertOrderedList" title="Numbered list">1. List</button>
                                    <button type="button" data-command="formatBlock" data-value="blockquote" title="Quote">Quote</button>
                                    <button type="button" data-link title="Insert link">Link</button>
                                    <button type="button" data-command="removeFormat" title="Clear formatting">Clear</button>
                                </div>
                                <div id="rich-editor" class="rich-editor" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Content body">
                                    @if (old('body'))
                                        {!! nl2br(e(old('body'))) !!}
                                    @elseif ($content->exists)
                                        {!! $content->body_html !!}
                                    @endif
                                </div>
                                <details class="source-box">
                                    <summary>Edit HTML source (advanced)</summary>
                                    <textarea id="body-source" name="body" rows="10" maxlength="50000" aria-label="HTML source">{{ old('body', $content->body) }}</textarea>
                                </details>
                                <p class="cell-sub" style="margin-top:6px">Scripts, event handlers, styles and unsafe URLs are removed when saved. Upload images through the media library and insert their URL if needed.</p>
                            </div>
                            <x-input name="published_at" label="Publish at" type="datetime-local" :value="$content->published_at?->format('Y-m-d\TH:i')" help="Leave blank to publish now when status is Published." />
                            <x-input name="sort_order" label="Sort order" type="number" min="0" :value="$content->sort_order ?? 0" />
                            <div class="span-2">
                                <input type="hidden" name="is_featured" value="0">
                                <label class="checkbox">
                                    <input type="checkbox" name="is_featured" value="1" @checked(old('is_featured', $content->is_featured))>
                                    <span>Feature this item on the home page</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="card">
                    <div class="card-header"><div><h3 class="card-title">Presentation</h3><p class="card-sub">Page template, search preview and social image</p></div></div>
                    <div class="form-section">
                        <div class="form-grid">
                            <x-select name="template" label="Page template" :options="['default' => 'Default', 'full-width' => 'Full width', 'sidebar' => 'With sidebar', 'landing' => 'Landing page']" :selected="$content->template ?? 'default'" />
                            <x-input name="meta_title" label="SEO title" :value="$content->meta_title" maxlength="200" help="Falls back to the content title." />
                            <div class="span-2">
                                <x-textarea name="meta_description" label="Meta description" rows="3" :value="$content->meta_description" maxlength="320" />
                            </div>
                            <div class="span-2">
                                <x-input name="image" label="Featured image" type="file" accept="image/jpeg,image/png,image/webp,image/gif" />
                                @if ($content->image_path)
                                    <img src="{{ $content->image_url }}" alt="" style="max-width:100%;max-height:150px;border-radius:8px;margin-top:8px">
                                    <p class="cell-sub">Current: {{ $content->image_path }}</p>
                                @endif
                            </div>
                            <div class="span-2">
                                <x-input name="og_image" label="Social sharing image" type="file" accept="image/jpeg,image/png,image/webp,image/gif" />
                                @if ($content->og_image_path)<p class="cell-sub">Current: {{ $content->og_image_path }}</p>@endif
                            </div>
                            <div class="span-2">
                                <x-input name="file" label="Downloadable file" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv" />
                                @if ($content->file_path)<p class="cell-sub">Current: {{ $content->file_path }}</p>@endif
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="display:flex;justify-content:flex-end;gap:8px">
                        <x-button :href="route('website-content.index')" variant="ghost">Cancel</x-button>
                        <x-button type="submit" variant="primary" icon="save">{{ $content->exists ? 'Save changes' : 'Create content' }}</x-button>
                    </div>
                </div>

                @if ($content->exists)
                    <div class="card" style="margin-top:16px">
                        <div class="card-header"><div><h3 class="card-title">Record</h3><p class="card-sub">Audit and lifecycle</p></div></div>
                        <div class="card-body">
                            <p class="muted" style="font-size:12px;margin-top:0">
                                Created {{ $content->created_at?->format('d M Y, h:i A') }}
                                @if ($content->editor) · last edited by {{ $content->editor->name }} @endif
                                @if ($content->publisher) · published by {{ $content->publisher->name }} @endif
                            </p>
                            @if ($content->status !== 'archived')
                                <form method="POST" action="{{ route('website-content.archive', $content) }}">
                                    @csrf
                                    <button class="btn btn-secondary btn-sm" type="submit">Archive content</button>
                                </form>
                            @endif
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </form>

    @if ($content->exists)
        <div class="card" style="margin-top:18px">
            <div class="card-header"><div><h3 class="card-title">Revision history</h3><p class="card-sub">Every save keeps the version it replaced. Restoring also saves the current version first.</p></div></div>
            <div class="table-wrap">
                <table class="data-table">
                    <thead><tr><th>When</th><th>By</th><th>Reason</th><th>Status at the time</th><th>Actions</th></tr></thead>
                    <tbody>
                        @forelse ($content->revisions as $revision)
                            <tr>
                                <td>{{ $revision->created_at?->format('d M Y, h:i A') }}</td>
                                <td>{{ $revision->user?->name ?? 'System' }}</td>
                                <td>{{ $revision->reason ?? '—' }}</td>
                                <td><x-badge color="muted">{{ ucfirst($revision->payload['status'] ?? 'unknown') }}</x-badge></td>
                                <td>
                                    @can('website.publish')
                                        <form method="POST" action="{{ route('website-content.revisions.restore', [$content, $revision]) }}" onsubmit="return confirm('Restore this revision? The current version will be saved first.')">
                                            @csrf
                                            <button class="btn btn-secondary btn-sm" type="submit">Restore</button>
                                        </form>
                                    @endcan
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5"><div class="empty-state">No revisions yet. They are created on the next save.</div></td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @can('website.manage')
            <div class="card" style="margin-top:18px;border-color:#f3c2c2">
                <div class="card-body" style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap">
                    <div><strong>Delete this content permanently</strong><p class="muted" style="margin:4px 0 0;font-size:12px">Revisions are deleted too. Shared media files are kept.</p></div>
                    <form method="POST" action="{{ route('website-content.destroy', $content) }}" onsubmit="return confirm('Permanently delete this content? This cannot be undone.')">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger" type="submit">Delete permanently</button>
                    </form>
                </div>
            </div>
        @endcan
    @endif
@endsection

@push('scripts')
    <script>
        (() => {
            const editor = document.getElementById('rich-editor');
            const source = document.getElementById('body-source');
            const form = document.getElementById('content-form');
            if (!editor || !source || !form) return;

            const sync = () => { source.value = editor.innerHTML.trim(); };
            editor.addEventListener('input', sync);
            source.addEventListener('input', () => { editor.innerHTML = source.value; });

            form.addEventListener('submit', sync);

            document.querySelectorAll('.rich-toolbar [data-command]').forEach((button) => {
                button.addEventListener('click', () => {
                    editor.focus();
                    document.execCommand(button.dataset.command, false, button.dataset.value || null);
                    sync();
                });
            });

            document.querySelectorAll('.rich-toolbar [data-block]').forEach((button) => {
                button.addEventListener('click', () => {
                    editor.focus();
                    document.execCommand('formatBlock', false, button.dataset.block);
                    sync();
                });
            });

            document.querySelector('[data-link]')?.addEventListener('click', () => {
                const url = window.prompt('Link URL (https://, mailto: or a relative path)');
                if (!url) return;
                editor.focus();
                document.execCommand('createLink', false, url);
                sync();
            });
        })();
    </script>
@endpush
