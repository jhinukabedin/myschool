<?php

use App\Http\Controllers\Admin\AcademicSessionController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\ContactMessageController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Admin\PortalAccountController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\SchoolClassController;
use App\Http\Controllers\Admin\SectionController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\WebsiteAdminController;
use App\Http\Controllers\Admin\WebsiteContentController;
use App\Http\Controllers\Admin\WebsiteMenuController;
use Illuminate\Support\Facades\Route;

Route::get('/admin', [AdminController::class, 'index'])
    ->middleware('permission:settings.view')->name('admin.index');

Route::prefix('sessions')->name('sessions.')->middleware('permission:academics.manage')->group(function () {
    Route::get('/', [AcademicSessionController::class, 'index'])->name('index');
    Route::post('/', [AcademicSessionController::class, 'store'])->name('store');
    Route::put('/{session}', [AcademicSessionController::class, 'update'])->name('update');
    Route::post('/{session}/activate', [AcademicSessionController::class, 'activate'])->name('activate');
    Route::delete('/{session}', [AcademicSessionController::class, 'destroy'])->name('destroy');
});

Route::prefix('classes')->name('classes.')->middleware('permission:academics.manage')->group(function () {
    Route::get('/', [SchoolClassController::class, 'index'])->name('index');
    Route::post('/', [SchoolClassController::class, 'store'])->name('store');
    Route::put('/{schoolClass}', [SchoolClassController::class, 'update'])->name('update');
    Route::delete('/{schoolClass}', [SchoolClassController::class, 'destroy'])->name('destroy');
});

Route::prefix('sections')->name('sections.')->middleware('permission:academics.manage')->group(function () {
    Route::get('/', [SectionController::class, 'index'])->name('index');
    Route::post('/', [SectionController::class, 'store'])->name('store');
    Route::put('/{section}', [SectionController::class, 'update'])->name('update');
    Route::delete('/{section}', [SectionController::class, 'destroy'])->name('destroy');
});

Route::prefix('users')->name('users.')->middleware('permission:users.manage')->group(function () {
    Route::get('/', [UserController::class, 'index'])->name('index');
    Route::get('/create', [UserController::class, 'create'])->name('create');
    Route::post('/', [UserController::class, 'store'])->name('store');
    Route::get('/{user}/edit', [UserController::class, 'edit'])->name('edit');
    Route::put('/{user}', [UserController::class, 'update'])->name('update');
    Route::post('/{user}/status', [UserController::class, 'toggle'])->name('toggle');
    Route::delete('/{user}', [UserController::class, 'destroy'])->name('destroy');
});

Route::prefix('roles')->name('roles.')->middleware('permission:users.manage')->group(function () {
    Route::get('/', [RoleController::class, 'index'])->name('index');
    Route::put('/{role}', [RoleController::class, 'update'])->name('update');
});

Route::get('/audit-log', [AuditLogController::class, 'index'])
    ->middleware('permission:audit.view')->name('audit.index');

Route::prefix('admin/portal-accounts')->name('portal-accounts.')
    ->middleware('permission:portals.manage')->group(function () {
        Route::get('/', [PortalAccountController::class, 'index'])->name('index');
        Route::post('/', [PortalAccountController::class, 'store'])->name('store');
        Route::delete('/students/{link}', [PortalAccountController::class, 'destroyStudent'])->name('students.destroy');
        Route::delete('/parents/{link}', [PortalAccountController::class, 'destroyParent'])->name('parents.destroy');
    });

Route::get('/settings', [SettingController::class, 'index'])
    ->middleware('permission:settings.view')->name('settings.index');
Route::put('/settings', [SettingController::class, 'update'])
    ->middleware('permission:settings.manage')->name('settings.update');

Route::prefix('admin/website')->name('website-admin.')->middleware('permission:website.view')->group(function () {
    Route::get('/', [WebsiteAdminController::class, 'index'])->name('index');
    Route::get('/design', [WebsiteAdminController::class, 'design'])->name('design');
    Route::put('/design', [WebsiteAdminController::class, 'updateDesign'])
        ->middleware('permission:website.manage')->name('design.update');

    // One dedicated function per homepage / public content area.
    foreach (array_keys(WebsiteContentController::SECTIONS) as $section) {
        Route::get('/'.$section, [WebsiteContentController::class, 'section'])
            ->defaults('section', $section)
            ->name($section);
    }
});

Route::prefix('admin/website/content')->name('website-content.')->middleware('permission:website.view')->group(function () {
    Route::get('/', [WebsiteContentController::class, 'index'])->name('index');
    Route::get('/create', [WebsiteContentController::class, 'create'])->middleware('permission:website.manage')->name('create');
    Route::post('/', [WebsiteContentController::class, 'store'])->middleware('permission:website.manage')->name('store');
    Route::get('/{content}/edit', [WebsiteContentController::class, 'edit'])->middleware('permission:website.manage')->name('edit');
    Route::put('/{content}', [WebsiteContentController::class, 'update'])->middleware('permission:website.manage')->name('update');
    Route::delete('/{content}', [WebsiteContentController::class, 'destroy'])->middleware('permission:website.manage')->name('destroy');
    Route::post('/{content}/archive', [WebsiteContentController::class, 'archive'])->middleware('permission:website.manage')->name('archive');
    Route::post('/{content}/revisions/{revision}/restore', [WebsiteContentController::class, 'restoreRevision'])
        ->middleware('permission:website.publish')->name('revisions.restore');
});

Route::prefix('admin/menus')->name('website-menus.')->middleware('permission:website.menus')->group(function () {
    Route::get('/', [WebsiteMenuController::class, 'index'])->name('index');
    Route::post('/', [WebsiteMenuController::class, 'store'])->name('store');
    Route::put('/{menu}', [WebsiteMenuController::class, 'update'])->name('update');
    Route::delete('/{menu}', [WebsiteMenuController::class, 'destroy'])->name('destroy');
    Route::post('/{menu}/items', [WebsiteMenuController::class, 'storeItem'])->name('items.store');
    Route::put('/items/{item}', [WebsiteMenuController::class, 'updateItem'])->name('items.update');
    Route::delete('/items/{item}', [WebsiteMenuController::class, 'destroyItem'])->name('items.destroy');
});

Route::prefix('admin/media')->name('media.')->middleware('permission:website.media')->group(function () {
    Route::get('/', [MediaController::class, 'index'])->name('index');
    Route::post('/', [MediaController::class, 'store'])->name('store');
    Route::put('/{medium}', [MediaController::class, 'update'])->name('update');
    Route::delete('/{medium}', [MediaController::class, 'destroy'])->name('destroy');
});

Route::prefix('admin/messages')->name('messages.')->middleware('permission:website.view')->group(function () {
    Route::get('/', [ContactMessageController::class, 'index'])->name('index');
    Route::get('/{message}', [ContactMessageController::class, 'show'])->name('show');
    Route::post('/{message}/status', [ContactMessageController::class, 'status'])->middleware('permission:website.manage')->name('status');
});
