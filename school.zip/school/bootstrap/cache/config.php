<?php return array (
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
      'limit' => NULL,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\resources\\views',
    ),
    'compiled' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\framework\\views',
  ),
  'app' => 
  array (
    'name' => 'EduSphere School',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost:8000',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'Asia/Dhaka',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:WN1O2NJCmYh0tbLTpQXbM2YqcD/2CaxVaLTv/UXP8dQ=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Benchmark' => 'Illuminate\\Support\\Benchmark',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'Uri' => 'Illuminate\\Support\\Uri',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'database',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'session' => 
      array (
        'driver' => 'session',
        'key' => '_cache',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\framework/cache/data',
        'lock_path' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => NULL,
        'secret' => NULL,
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'stores' => 
        array (
          0 => 'database',
          1 => 'array',
        ),
      ),
    ),
    'prefix' => 'edusphere_school_cache_',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'school',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'school',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'school',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'school',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'school',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'edusphere_school_database_',
        'persistent' => false,
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'public',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\app/private',
        'serve' => true,
        'throw' => false,
        'report' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\app/public',
        'url' => 'http://localhost:8000/storage',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      'C:\\Users\\Jhinuk\\BHServe\\www\\school\\public\\storage' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\app/public',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'log',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => NULL,
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '2525',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => 'localhost',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'no-reply@edusphere.test',
      'name' => 'EduSphere School',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\resources\\views/vendor/mail',
      ),
      'extensions' => 
      array (
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => NULL,
        'secret' => NULL,
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
      'deferred' => 
      array (
        'driver' => 'deferred',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'connections' => 
        array (
          0 => 'database',
          1 => 'deferred',
        ),
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'school' => 
  array (
    'currency' => '৳',
    'currency_code' => 'BDT',
    'date_format' => 'd M Y',
    'timezone' => 'Asia/Dhaka',
    'default_password' => 'School@12345',
    'permissions' => 
    array (
      'dashboard.view' => 
      array (
        'name' => 'View dashboard',
        'module' => 'Dashboard',
      ),
      'students.view' => 
      array (
        'name' => 'View students',
        'module' => 'Students',
      ),
      'students.create' => 
      array (
        'name' => 'Admit / create students',
        'module' => 'Students',
      ),
      'students.update' => 
      array (
        'name' => 'Edit students',
        'module' => 'Students',
      ),
      'students.archive' => 
      array (
        'name' => 'Archive / change student status',
        'module' => 'Students',
      ),
      'students.promote' => 
      array (
        'name' => 'Promote students',
        'module' => 'Students',
      ),
      'enquiries.view' => 
      array (
        'name' => 'View admission enquiries',
        'module' => 'Students',
      ),
      'enquiries.manage' => 
      array (
        'name' => 'Manage admission enquiries',
        'module' => 'Students',
      ),
      'academics.view' => 
      array (
        'name' => 'View academic setup',
        'module' => 'Academics',
      ),
      'academics.manage' => 
      array (
        'name' => 'Manage sessions, classes and subjects',
        'module' => 'Academics',
      ),
      'fees.view' => 
      array (
        'name' => 'View fee structures and dues',
        'module' => 'Fees',
      ),
      'fees.manage' => 
      array (
        'name' => 'Manage fee structures and assignments',
        'module' => 'Fees',
      ),
      'fees.collect' => 
      array (
        'name' => 'Collect fees and issue receipts',
        'module' => 'Fees',
      ),
      'fees.reverse' => 
      array (
        'name' => 'Cancel or refund payments',
        'module' => 'Fees',
      ),
      'fees.waive' => 
      array (
        'name' => 'Approve waivers and adjustments',
        'module' => 'Fees',
      ),
      'attendance.view' => 
      array (
        'name' => 'View attendance',
        'module' => 'Attendance',
      ),
      'attendance.manage' => 
      array (
        'name' => 'Mark attendance',
        'module' => 'Attendance',
      ),
      'attendance.report' => 
      array (
        'name' => 'View attendance reports',
        'module' => 'Attendance',
      ),
      'exams.view' => 
      array (
        'name' => 'View examinations',
        'module' => 'Academics',
      ),
      'exams.manage' => 
      array (
        'name' => 'Manage examinations and schedules',
        'module' => 'Academics',
      ),
      'marks.enter' => 
      array (
        'name' => 'Enter marks',
        'module' => 'Academics',
      ),
      'marks.submit' => 
      array (
        'name' => 'Submit marks for approval',
        'module' => 'Academics',
      ),
      'marks.approve' => 
      array (
        'name' => 'Approve and finalize marks',
        'module' => 'Academics',
      ),
      'marks.correct' => 
      array (
        'name' => 'Correct finalized marks',
        'module' => 'Academics',
      ),
      'results.view' => 
      array (
        'name' => 'View and print results',
        'module' => 'Academics',
      ),
      'assignments.view' => 
      array (
        'name' => 'View teacher assignments',
        'module' => 'Academics',
      ),
      'assignments.manage' => 
      array (
        'name' => 'Manage teacher assignments',
        'module' => 'Academics',
      ),
      'finance.view' => 
      array (
        'name' => 'View expenses and finance',
        'module' => 'Finance',
      ),
      'finance.manage' => 
      array (
        'name' => 'Manage expenses',
        'module' => 'Finance',
      ),
      'staff.view' => 
      array (
        'name' => 'View staff profiles',
        'module' => 'Staff',
      ),
      'staff.manage' => 
      array (
        'name' => 'Manage staff profiles',
        'module' => 'Staff',
      ),
      'payroll.view' => 
      array (
        'name' => 'View salary information',
        'module' => 'Payroll',
      ),
      'payroll.manage' => 
      array (
        'name' => 'Process payroll and salary payments',
        'module' => 'Payroll',
      ),
      'notices.view' => 
      array (
        'name' => 'View notices',
        'module' => 'Communication',
      ),
      'notices.manage' => 
      array (
        'name' => 'Manage notices',
        'module' => 'Communication',
      ),
      'communication.whatsapp' => 
      array (
        'name' => 'Send WhatsApp reminders',
        'module' => 'Communication',
      ),
      'reports.view' => 
      array (
        'name' => 'View reports',
        'module' => 'Reports',
      ),
      'reports.export' => 
      array (
        'name' => 'Export reports',
        'module' => 'Reports',
      ),
      'settings.view' => 
      array (
        'name' => 'View settings',
        'module' => 'Administration',
      ),
      'settings.manage' => 
      array (
        'name' => 'Manage school settings',
        'module' => 'Administration',
      ),
      'users.manage' => 
      array (
        'name' => 'Manage users and roles',
        'module' => 'Administration',
      ),
      'audit.view' => 
      array (
        'name' => 'View audit logs',
        'module' => 'Administration',
      ),
      'website.view' => 
      array (
        'name' => 'View website content and messages',
        'module' => 'Website',
      ),
      'website.manage' => 
      array (
        'name' => 'Manage website content and messages',
        'module' => 'Website',
      ),
      'website.publish' => 
      array (
        'name' => 'Publish, unpublish and restore website content',
        'module' => 'Website',
      ),
      'website.media' => 
      array (
        'name' => 'Manage the website media library',
        'module' => 'Website',
      ),
      'website.menus' => 
      array (
        'name' => 'Manage public website menus',
        'module' => 'Website',
      ),
      'website.code' => 
      array (
        'name' => 'Edit approved website code snippets',
        'module' => 'Website',
      ),
      'portals.manage' => 
      array (
        'name' => 'Create and link student/parent portal accounts',
        'module' => 'Portals',
      ),
    ),
    'roles' => 
    array (
      'super-admin' => 
      array (
        'name' => 'Super Administrator',
        'description' => 'Unrestricted access to every module.',
        'permissions' => '*',
      ),
      'admin' => 
      array (
        'name' => 'Administrator',
        'description' => 'Runs day-to-day academic and administrative operations.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'students.view',
          2 => 'students.create',
          3 => 'students.update',
          4 => 'students.archive',
          5 => 'students.promote',
          6 => 'enquiries.view',
          7 => 'enquiries.manage',
          8 => 'academics.view',
          9 => 'academics.manage',
          10 => 'fees.view',
          11 => 'fees.manage',
          12 => 'fees.collect',
          13 => 'fees.reverse',
          14 => 'fees.waive',
          15 => 'attendance.view',
          16 => 'attendance.manage',
          17 => 'attendance.report',
          18 => 'exams.view',
          19 => 'exams.manage',
          20 => 'marks.enter',
          21 => 'marks.submit',
          22 => 'marks.approve',
          23 => 'marks.correct',
          24 => 'results.view',
          25 => 'assignments.view',
          26 => 'assignments.manage',
          27 => 'finance.view',
          28 => 'finance.manage',
          29 => 'staff.view',
          30 => 'staff.manage',
          31 => 'payroll.view',
          32 => 'payroll.manage',
          33 => 'notices.view',
          34 => 'notices.manage',
          35 => 'communication.whatsapp',
          36 => 'reports.view',
          37 => 'reports.export',
          38 => 'settings.view',
          39 => 'audit.view',
          40 => 'website.view',
          41 => 'website.manage',
          42 => 'website.publish',
          43 => 'website.media',
          44 => 'website.menus',
          45 => 'website.code',
          46 => 'portals.manage',
        ),
      ),
      'accountant' => 
      array (
        'name' => 'Accountant',
        'description' => 'Handles fee collection, expenses and financial reporting.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'students.view',
          2 => 'fees.view',
          3 => 'fees.collect',
          4 => 'fees.reverse',
          5 => 'fees.waive',
          6 => 'finance.view',
          7 => 'finance.manage',
          8 => 'payroll.view',
          9 => 'payroll.manage',
          10 => 'reports.view',
          11 => 'reports.export',
          12 => 'notices.view',
        ),
      ),
      'teacher' => 
      array (
        'name' => 'Teacher',
        'description' => 'Marks attendance, enters marks and views results.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'students.view',
          2 => 'academics.view',
          3 => 'attendance.view',
          4 => 'attendance.manage',
          5 => 'attendance.report',
          6 => 'exams.view',
          7 => 'marks.enter',
          8 => 'marks.submit',
          9 => 'results.view',
          10 => 'notices.view',
        ),
      ),
      'registrar' => 
      array (
        'name' => 'Registrar',
        'description' => 'Manages admissions, student records and promotion.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'students.view',
          2 => 'students.create',
          3 => 'students.update',
          4 => 'students.archive',
          5 => 'students.promote',
          6 => 'enquiries.view',
          7 => 'enquiries.manage',
          8 => 'academics.view',
          9 => 'assignments.view',
          10 => 'fees.view',
          11 => 'notices.view',
          12 => 'reports.view',
          13 => 'website.view',
        ),
      ),
      'staff' => 
      array (
        'name' => 'Staff',
        'description' => 'Read-only dashboard and notices access.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'notices.view',
        ),
      ),
      'student' => 
      array (
        'name' => 'Student',
        'description' => 'Student portal access only. Records are restricted to the linked student.',
        'permissions' => 
        array (
        ),
      ),
      'parent' => 
      array (
        'name' => 'Parent / Guardian',
        'description' => 'Parent portal access only. Records are restricted to explicitly linked children.',
        'permissions' => 
        array (
        ),
      ),
      'website-admin' => 
      array (
        'name' => 'Website Administrator',
        'description' => 'Manages the public website, menus, media and approved code snippets.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'website.view',
          2 => 'website.manage',
          3 => 'website.publish',
          4 => 'website.media',
          5 => 'website.menus',
          6 => 'website.code',
        ),
      ),
      'website-editor' => 
      array (
        'name' => 'Website Editor',
        'description' => 'Creates and publishes pages, news, events and gallery items.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'website.view',
          2 => 'website.manage',
          3 => 'website.publish',
          4 => 'website.media',
        ),
      ),
      'media-manager' => 
      array (
        'name' => 'Media Manager',
        'description' => 'Uploads, previews and removes website media without access to academic or financial records.',
        'permissions' => 
        array (
          0 => 'dashboard.view',
          1 => 'website.view',
          2 => 'website.media',
        ),
      ),
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'database',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\Users\\Jhinuk\\BHServe\\www\\school\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'edusphere_school_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
    'trust_project' => 'always',
  ),
);
