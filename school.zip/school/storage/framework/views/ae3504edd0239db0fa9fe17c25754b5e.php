<?php $__env->startSection('title', 'শিক্ষাক্রম'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / শিক্ষাক্রম</div><h1>শিক্ষাক্রম</h1><p>ক্লাসভিত্তিক বিষয় ও একাডেমিক কার্যক্রম</p></div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title">একাডেমিক কার্যক্রম</h2><span class="badge"><?php echo e($session?->name ?? 'চলমান সেশন'); ?></span></div>
        <div class="card article" style="margin-bottom:18px">
            <p>আমাদের শিক্ষাক্রম শিক্ষার্থীদের মৌলিক জ্ঞান, সৃজনশীলতা ও সমস্যা সমাধানের দক্ষতা গড়ে তোলার লক্ষ্যে সাজানো হয়েছে। প্রতিটি ক্লাসের জন্য নির্ধারিত বিষয়, পাঠ্যক্রম ও মূল্যায়ন পদ্ধতি নিচে দেওয়া হয়েছে।</p>
            <p><a href="<?php echo e(route('website.downloads')); ?>">সিলেবাস ও গুরুত্বপূর্ণ ফাইল ডাউনলোড করুন →</a> · <a href="<?php echo e(route('website.calendar')); ?>">একাডেমিক ক্যালেন্ডার দেখুন →</a></p>
        </div>

        <div id="classes" class="academic-grid" style="grid-template-columns:repeat(2,1fr)">
            <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="card article">
                    <h3 style="margin-top:0"><?php echo e($class->name); ?></h3>
                    <?php if($class->subjects->isEmpty()): ?>
                        <p>এই ক্লাসের বিষয়সমূহ শীঘ্রই প্রকাশিত হবে।</p>
                    <?php else: ?>
                        <ul>
                            <?php $__currentLoopData = $class->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($mapping->subject?->name ?? 'বিষয়'); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card article"><p>এখনো কোনো ক্লাস বা বিষয় কনফিগার করা হয়নি।</p></div>
            <?php endif; ?>
        </div>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\academics.blade.php ENDPATH**/ ?>