<?php $__env->startSection('title', 'প্রচ্ছদ'); ?>

<?php
    $messageCards = [
        [
            'model' => $presidentMessage,
            'title' => 'সভাপতির বাণী',
            'role' => 'সভাপতি',
            'fallback' => 'শিক্ষা শুধু পরীক্ষায় ভালো ফল করার মাধ্যম নয়। এটি একজন মানুষকে দায়িত্বশীল, মানবিক ও আত্মনির্ভর করে গড়ে তোলে। আমাদের বিদ্যালয় সেই লক্ষ্যেই কাজ করে যাচ্ছে।',
            'route' => route('website.president-message'),
        ],
        [
            'model' => $administrationMessage,
            'title' => 'প্রশাসনের বাণী',
            'role' => 'প্রশাসন',
            'fallback' => 'একটি সুসংগঠিত শিক্ষা পরিবেশ, দক্ষ শিক্ষকমণ্ডলী ও অভিভাবকদের সহযোগিতা—এই তিনটি শক্তির সমন্বয়ে আমরা প্রতিটি শিক্ষার্থীর সম্ভাবনাকে বিকশিত করতে চাই।',
            'route' => route('website.administration-message'),
        ],
        [
            'model' => $principalMessage,
            'title' => 'প্রধান শিক্ষকের বাণী',
            'role' => 'প্রধান শিক্ষক',
            'fallback' => 'প্রতিটি শিক্ষার্থীর ভেতরে আলাদা সম্ভাবনা রয়েছে। সঠিক দিকনির্দেশনা, অধ্যবসায় ও সুন্দর পরিবেশের মাধ্যমে সেই সম্ভাবনাকে বিকশিত করাই আমাদের প্রধান লক্ষ্য।',
            'route' => route('website.principal-message'),
        ],
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="hero"><div class="container hero-wrap">
        <div class="hero-slider">
            <?php if($slider->isNotEmpty()): ?>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="hero-slide <?php echo e($loop->first ? 'active' : ''); ?>"
                        <?php if($slide->image_url): ?> style="background-image:linear-gradient(120deg,rgba(10,30,55,.78),rgba(30,60,95,.45)),url('<?php echo e($slide->image_url); ?>');background-size:cover;background-position:center" <?php else: ?> style="background-image:linear-gradient(135deg,#385d79,#8eabc0)" <?php endif; ?>>
                        <div class="hero-content">
                            <span class="hero-kicker"><?php echo e($slide->category ?: 'স্বাগতম'); ?></span>
                            <h2><?php echo e($slide->title); ?></h2>
                            <p><?php echo e($slide->excerpt ?: Str::limit(strip_tags($slide->body), 190)); ?></p>
                            <?php if($slide->link_url || $slide->button_label): ?>
                                <a class="btn btn-light" href="<?php echo e($slide->link_url ?: route('website.about')); ?>"><?php echo e($slide->button_label ?: 'বিস্তারিত দেখুন'); ?> →</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($slider->count() > 1): ?>
                    <div class="hero-dots">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="hero-dot <?php echo e($loop->first ? 'active' : ''); ?>"></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="hero-slide active" style="background-image:linear-gradient(135deg,#87634e,#c5a38e)">
                    <div class="hero-content"><span class="hero-kicker">স্বাগতম</span><h2><?php echo e($siteNameBn); ?></h2><p>জ্ঞান, শৃঙ্খলা, নৈতিকতা ও আধুনিক প্রযুক্তির সমন্বয়ে শিক্ষার্থীদের ভবিষ্যতের জন্য প্রস্তুত করার প্রত্যয়।</p><a class="btn btn-light" href="<?php echo e(route('website.about')); ?>">বিদ্যালয় সম্পর্কে জানুন →</a></div>
                </div>
                <div class="hero-slide" style="background-image:linear-gradient(135deg,#385d79,#8eabc0)">
                    <div class="hero-content"><span class="hero-kicker">শিক্ষাই শক্তি</span><h2>সুশিক্ষাই সুন্দর ভবিষ্যৎ</h2><p>শিক্ষার্থীর মেধা, সৃজনশীলতা ও মানবিক মূল্যবোধ বিকাশে আমরা প্রতিশ্রুতিবদ্ধ।</p><a class="btn btn-light" href="<?php echo e(route('website.academics')); ?>">শিক্ষাক্রম দেখুন →</a></div>
                </div>
                <div class="hero-slide" style="background-image:linear-gradient(135deg,#5c4974,#b39ac9)">
                    <div class="hero-content"><span class="hero-kicker">নতুন ভর্তি</span><h2>ভর্তি সংক্রান্ত তথ্য</h2><p>ভর্তি প্রক্রিয়া, প্রয়োজনীয় কাগজপত্র ও গুরুত্বপূর্ণ নির্দেশনা এক জায়গায়।</p><a class="btn btn-light" href="<?php echo e(route('website.admission')); ?>">ভর্তি তথ্য →</a></div>
                </div>
                <div class="hero-dots"><span class="hero-dot active"></span><span class="hero-dot"></span><span class="hero-dot"></span></div>
            <?php endif; ?>
        </div>
        <div class="quick-panel">
            <a class="quick-item" href="<?php echo e(route('website.calendar')); ?>"><span class="quick-icon">▣</span><strong>একাডেমিক ক্যালেন্ডার</strong><small>শ্রেণিভিত্তিক সময়সূচি</small></a>
            <a class="quick-item" href="<?php echo e(route('website.notices')); ?>"><span class="quick-icon">▤</span><strong>নোটিশ বোর্ড</strong><small>সর্বশেষ ঘোষণা</small></a>
            <a class="quick-item" href="<?php echo e(route('website.admission.apply')); ?>"><span class="quick-icon">◫</span><strong>ভর্তি আবেদন</strong><small>অনলাইনে আবেদন করুন</small></a>
            <a class="quick-item" href="<?php echo e(route('website.downloads')); ?>"><span class="quick-icon">↓</span><strong>ডাউনলোড</strong><small>গুরুত্বপূর্ণ ফাইল</small></a>
        </div>
    </div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title"><?php echo e($introduction?->title ?: 'প্রতিষ্ঠানের পরিচিতি'); ?></h2><a class="section-link" href="<?php echo e(route('website.about')); ?>">বিস্তারিত দেখুন →</a></div>
        <div class="feature-grid">
            <article class="card history-card reveal"><div class="history-inner">
                <div class="school-photo" <?php if($introduction?->image_url): ?> style="background-image:url('<?php echo e($introduction->image_url); ?>');background-size:cover;background-position:center" <?php endif; ?>></div>
                <div class="history-text">
                    <h3><?php echo e($introduction?->excerpt ?: 'আলোকিত প্রজন্ম গড়ার অঙ্গীকার'); ?></h3>
                    <?php if($introduction): ?>
                        <div class="home-rich-body"><?php echo $introduction->body_html; ?></div>
                        <?php if($introduction->button_label): ?>
                            <a class="btn btn-purple" href="<?php echo e($introduction->link_url ?: route('website.about')); ?>"><?php echo e($introduction->button_label); ?></a>
                        <?php else: ?>
                            <a class="btn btn-purple" href="<?php echo e(route('website.about')); ?>">আরও জানুন</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <p><?php echo e($siteNameBn); ?> শিক্ষার্থীদের জ্ঞান অর্জনের পাশাপাশি নৈতিকতা, শৃঙ্খলা, নেতৃত্ব ও সৃজনশীলতার বিকাশে গুরুত্ব দেয়। আমাদের লক্ষ্য একটি নিরাপদ, আনন্দময় ও আধুনিক শিক্ষার পরিবেশ তৈরি করা।</p>
                        <p>দক্ষ শিক্ষক, নিয়মিত একাডেমিক কার্যক্রম এবং সহশিক্ষা কার্যক্রমের মাধ্যমে প্রতিটি শিক্ষার্থীকে তার সম্ভাবনার সর্বোচ্চ পর্যায়ে পৌঁছাতে সহায়তা করা হয়।</p>
                        <a class="btn btn-purple" href="<?php echo e(route('website.about')); ?>">আরও জানুন</a>
                    <?php endif; ?>
                </div>
            </div></article>
            <aside class="card notice-card reveal"><div class="panel-head"><h3>নোটিশ বোর্ড</h3><a href="<?php echo e(route('website.notices')); ?>">সব দেখুন</a></div>
                <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="notice-row" href="<?php echo e(route('website.notice', $notice)); ?>">
                        <span class="notice-date"><?php echo e($notice->publish_at?->format('d') ?? $notice->created_at?->format('d')); ?><br><?php echo e($notice->publish_at?->format('M') ?? $notice->created_at?->format('M')); ?></span>
                        <span><?php echo e($notice->title); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="notice-row"><span class="notice-date">—</span><span>বর্তমানে কোনো প্রকাশিত নোটিশ নেই।</span></div>
                <?php endif; ?>
            </aside>
        </div>
    </div></section>

    <section class="section" style="background:#f7f8fb"><div class="container">
        <div class="section-head"><h2 class="section-title">প্রশাসনের বাণী</h2><a class="section-link" href="<?php echo e(route('website.principal-message')); ?>">প্রধান শিক্ষকের বাণী →</a></div>
        <div class="message-grid">
            <?php $__currentLoopData = $messageCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($message = $card['model']); ?>
                <article class="card message-card reveal">
                    <div class="person-photo" <?php if($message?->image_url): ?> style="background-image:url('<?php echo e($message->image_url); ?>');background-size:cover;background-position:center;color:transparent" <?php endif; ?>><?php echo e($message ? '' : $card['role']); ?></div>
                    <div>
                        <h3><?php echo e($message?->title ?: $card['title']); ?></h3>
                        <p><?php echo e($message?->excerpt ?: Str::limit(strip_tags($message?->body ?? ''), 220) ?: $card['fallback']); ?></p>
                        <p style="margin-top:8px"><b><?php echo e($message?->category ?: $card['role']); ?></b><br><?php echo e($siteNameBn); ?></p>
                        <a class="section-link" href="<?php echo e($card['route']); ?>">বিস্তারিত পড়ুন →</a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title">একাডেমিক কর্নার</h2><a class="section-link" href="<?php echo e(route('website.academics')); ?>">সব দেখুন →</a></div>
        <div class="academic-grid">
            <?php if($academicItems->isNotEmpty()): ?>
                <?php $__currentLoopData = $academicItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="card academic-card reveal" href="<?php echo e($item->link_url ?: route('website.academics')); ?>">
                        <?php if($item->image_url): ?>
                            <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->title); ?>" style="width:48px;height:48px;object-fit:cover;border-radius:12px;margin-bottom:8px">
                        <?php else: ?>
                            <div class="academic-icon"><?php echo e($item->category ?: '◆'); ?></div>
                        <?php endif; ?>
                        <h3><?php echo e($item->title); ?></h3>
                        <p><?php echo e($item->excerpt ?: Str::limit(strip_tags($item->body), 100)); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <a class="card academic-card reveal" href="<?php echo e(route('website.academics')); ?>"><div class="academic-icon">♙</div><h3>ক্লাস ও বিষয়</h3><p><?php echo e($stats['classes']); ?>টি ক্লাসের বিষয়ভিত্তিক তথ্য</p></a>
                <a class="card academic-card reveal" href="<?php echo e(route('website.faculty')); ?>"><div class="academic-icon">♙</div><h3>শিক্ষকবৃন্দ</h3><p>অভিজ্ঞ ও নিবেদিত শিক্ষক মণ্ডলী</p></a>
                <a class="card academic-card reveal" href="<?php echo e(route('website.calendar')); ?>"><div class="academic-icon">◫</div><h3>ক্যালেন্ডার</h3><p>পরীক্ষা ও একাডেমিক সময়সূচি</p></a>
                <a class="card academic-card reveal" href="<?php echo e(route('website.downloads')); ?>"><div class="academic-icon">▤</div><h3>ডাউনলোড</h3><p>সিলেবাস ও গুরুত্বপূর্ণ ফাইল</p></a>
            <?php endif; ?>
        </div>
    </div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title">সর্বশেষ খবর ও অনুষ্ঠান</h2><a class="section-link" href="<?php echo e(route('website.news')); ?>">সব খবর →</a></div>
        <div class="news-grid">
            <div class="card news-list reveal">
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="news-item" href="<?php echo e(route('website.news.item', $item->slug)); ?>">
                        <div class="news-thumb" <?php if($item->image_url): ?> style="background-image:url('<?php echo e($item->image_url); ?>');background-size:cover;background-position:center" <?php endif; ?>></div>
                        <div><h3><?php echo e($item->title); ?></h3><p><?php echo e($item->excerpt ?: Str::limit(strip_tags($item->body), 110)); ?></p></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="news-item"><div class="news-thumb"></div><div><h3>খবর শীঘ্রই প্রকাশিত হবে</h3><p>প্রকাশিত সংবাদ এখানে দেখা যাবে।</p></div></div>
                <?php endif; ?>
            </div>
            <div class="card reveal"><div class="panel-head"><h3>ফটো গ্যালারি</h3><a href="<?php echo e(route('website.gallery')); ?>">সব ছবি</a></div><div class="gallery-grid">
                <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($item->image_url): ?>
                        <button type="button" class="gallery-item" data-home-gallery-image="<?php echo e($item->image_url); ?>" data-home-gallery-title="<?php echo e($item->title); ?>" aria-label="<?php echo e($item->title); ?> ছবিটি দেখুন">
                            <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->title); ?>" style="width:100%;height:100%;object-fit:cover">
                            <span><?php echo e($item->title); ?></span>
                        </button>
                    <?php else: ?>
                        <a class="gallery-item" href="<?php echo e(route('website.gallery')); ?>"><span><?php echo e($item->title); ?></span></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <a class="gallery-item" href="<?php echo e(route('website.gallery')); ?>"><span>বিদ্যালয় ক্যাম্পাস</span></a>
                    <a class="gallery-item" href="<?php echo e(route('website.gallery')); ?>"><span>শ্রেণিকক্ষ</span></a>
                <?php endif; ?>
            </div></div>
        </div>
        <div class="card reveal" style="margin-top:16px">
            <div class="panel-head"><h3>আসন্ন অনুষ্ঠান</h3><a href="<?php echo e(route('website.events')); ?>">সব অনুষ্ঠান</a></div>
            <div class="event-list">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="event-row" href="<?php echo e(route('website.events')); ?>">
                        <span class="event-date"><strong><?php echo e($event->published_at?->format('d') ?? '—'); ?></strong><small><?php echo e($event->published_at?->format('M') ?? ''); ?></small></span>
                        <span><strong><?php echo e($event->title); ?></strong><small><?php echo e($event->excerpt ?: Str::limit(strip_tags($event->body), 140)); ?></small></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="event-row"><span class="event-date"><strong>—</strong><small></small></span><span><strong>আসন্ন কোনো অনুষ্ঠান নেই</strong><small>নতুন অনুষ্ঠান প্রকাশিত হলে এখানে দেখা যাবে।</small></span></div>
                <?php endif; ?>
            </div>
        </div>
    </div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title">এক নজরে</h2></div>
        <div class="card stats"><div class="stats-grid">
            <div class="stat"><strong><?php echo e($stats['classes']); ?></strong><span>ক্লাস</span></div>
            <div class="stat"><strong><?php echo e($stats['notices']); ?></strong><span>প্রকাশিত নোটিশ</span></div>
            <div class="stat"><strong><?php echo e($stats['news']); ?></strong><span>সংবাদ</span></div>
            <div class="stat"><strong><?php echo e($stats['events']); ?></strong><span>ইভেন্ট</span></div>
        </div></div>
    </div></section>

    <section class="section"><div class="container"><div class="contact-grid">
        <div class="card contact-card reveal"><div class="section-head"><h2 class="section-title">যোগাযোগ</h2></div>
            <?php if($siteAddress): ?><div class="contact-item"><span>⌖</span><div><b>ঠিকানা</b><span><?php echo e($siteAddress); ?></span></div></div><?php endif; ?>
            <?php if($sitePhone): ?><div class="contact-item"><span>☎</span><div><b>ফোন</b><span><?php echo e($sitePhone); ?></span></div></div><?php endif; ?>
            <?php if($siteEmail): ?><div class="contact-item"><span>✉</span><div><b>ইমেইল</b><span><?php echo e($siteEmail); ?></span></div></div><?php endif; ?>
            <p style="margin-top:12px"><a class="btn btn-purple" href="<?php echo e(route('website.contact')); ?>">যোগাযোগ করুন</a></p>
        </div>
        <div class="map-box card reveal" style="display:flex;align-items:center;justify-content:center;min-height:220px;padding:24px;text-align:center">
            <div><strong><?php echo e($siteNameBn); ?></strong><p style="margin-top:8px;color:#6e7988"><?php echo e($siteAddress); ?></p><p style="color:#6e7988"><?php echo e($sitePhone); ?><?php echo e($sitePhone && $siteEmail ? ' · ' : ''); ?><?php echo e($siteEmail); ?></p></div>
        </div>
    </div></div></section>

    <dialog class="gallery-lightbox" id="home-gallery-lightbox" aria-label="Gallery image preview">
        <div class="gallery-shell">
            <img id="home-gallery-image" src="" alt="">
            <div class="gallery-bar">
                <span id="home-gallery-caption"></span>
                <div class="actions">
                    <button type="button" data-home-gallery-prev aria-label="Previous image">←</button>
                    <button type="button" data-home-gallery-next aria-label="Next image">→</button>
                    <button type="button" data-home-gallery-close>বন্ধ করুন</button>
                </div>
            </div>
        </div>
    </dialog>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
    <style>
        .home-rich-body { color: #4b5565; }
        .home-rich-body p { margin: 0 0 10px; }
        .home-rich-body p:last-child { margin-bottom: 14px; }
        .home-rich-body img { max-width: 100%; height: auto; border-radius: 10px; }
        .site-logo { max-height: 64px; max-width: 170px; width: auto; object-fit: contain; }
        .person-photo { background-size: cover; background-position: center; }
        dialog.gallery-lightbox { border: 0; padding: 0; background: transparent; max-width: min(1100px, 95vw); max-height: 94vh; }
        dialog.gallery-lightbox::backdrop { background: rgba(5, 12, 24, .86); }
        .gallery-shell { background: #0c1424; border-radius: 14px; overflow: hidden; box-shadow: 0 30px 90px rgba(0,0,0,.5); }
        .gallery-shell img { display: block; max-width: 100%; max-height: 80vh; margin: 0 auto; }
        .gallery-bar { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 14px; color: #e6edf7; font-size: 13px; }
        .gallery-bar .actions { display: flex; gap: 8px; }
        .gallery-bar button { border: 1px solid rgba(255,255,255,.25); background: rgba(255,255,255,.1); color: #fff; border-radius: 8px; padding: 6px 10px; cursor: pointer; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const items = Array.from(document.querySelectorAll('[data-home-gallery-image]'));
            const dialog = document.getElementById('home-gallery-lightbox');
            const image = document.getElementById('home-gallery-image');
            const caption = document.getElementById('home-gallery-caption');
            if (!items.length || !dialog || !image || !caption) return;

            let active = 0;
            const show = (index) => {
                active = (index + items.length) % items.length;
                const item = items[active];
                image.src = item.dataset.homeGalleryImage;
                image.alt = item.dataset.homeGalleryTitle || '';
                caption.textContent = item.dataset.homeGalleryTitle || '';
                if (!dialog.open) dialog.showModal();
            };

            items.forEach((item, index) => item.addEventListener('click', () => show(index)));
            document.querySelector('[data-home-gallery-prev]')?.addEventListener('click', () => show(active - 1));
            document.querySelector('[data-home-gallery-next]')?.addEventListener('click', () => show(active + 1));
            document.querySelector('[data-home-gallery-close]')?.addEventListener('click', () => dialog.close());
            dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
            dialog.addEventListener('keydown', (event) => {
                if (event.key === 'ArrowLeft') show(active - 1);
                if (event.key === 'ArrowRight') show(active + 1);
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\home.blade.php ENDPATH**/ ?>