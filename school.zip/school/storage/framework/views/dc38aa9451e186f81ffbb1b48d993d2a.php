<?php $__env->startSection('title', 'শিক্ষকবৃন্দ'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / শিক্ষকবৃন্দ</div><h1>শিক্ষকবৃন্দ</h1><p>আমাদের অভিজ্ঞ ও নিবেদিত শিক্ষকমণ্ডলী</p></div></section>

    <section class="section"><div class="container">
        <div class="section-head"><h2 class="section-title">শিক্ষক তালিকা</h2><span class="badge"><?php echo e($profiles->count()); ?> জন</span></div>
        <div class="academic-grid">
            <?php $__empty_1 = true; $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="card article reveal" style="text-align:center">
                    <?php if($profile->image_url): ?>
                        <img src="<?php echo e($profile->image_url); ?>" alt="<?php echo e($profile->title); ?>" style="width:110px;height:110px;border-radius:50%;object-fit:cover;margin:0 auto 12px">
                    <?php else: ?>
                        <div class="person-photo" style="margin:0 auto 12px"><?php echo e(Str::substr($profile->title, 0, 1)); ?></div>
                    <?php endif; ?>
                    <h3 style="margin:0 0 4px"><?php echo e($profile->title); ?></h3>
                    <?php if($profile->category): ?><p class="badge" style="display:inline-block"><?php echo e($profile->category); ?></p><?php endif; ?>
                    <?php if($profile->excerpt): ?><p style="margin-top:10px"><?php echo e($profile->excerpt); ?></p><?php endif; ?>
                    <?php if($profile->body): ?><div style="margin-top:8px"><?php echo $profile->body_html; ?></div><?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card article" style="grid-column:1/-1"><p>শিক্ষকদের তথ্য শীঘ্রই প্রকাশিত হবে। বিদ্যালয় অফিসের সাথে যোগাযোগ করুন।</p></div>
            <?php endif; ?>
        </div>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\faculty.blade.php ENDPATH**/ ?>