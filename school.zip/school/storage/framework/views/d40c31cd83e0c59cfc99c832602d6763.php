<?php $__env->startSection('title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Student portal</p>
            <h1>My Profile</h1>
            <p>Your admission details and family contact information. Ask the school office if anything needs correction.</p>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route('student.dashboard')); ?>">Back to dashboard</a>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head"><div><h2>Personal information</h2><p>Official school record</p></div></div>
            <div class="card-body">
                <div class="grid grid-2">
                    <div><div class="small muted">Full name</div><strong><?php echo e($student->full_name); ?></strong></div>
                    <div><div class="small muted">Student ID</div><strong class="mono"><?php echo e($student->student_code ?? '—'); ?></strong></div>
                    <div><div class="small muted">Admission no</div><strong class="mono"><?php echo e($student->admission_no); ?></strong></div>
                    <div><div class="small muted">Date of birth</div><strong><?php echo e($student->date_of_birth?->format('d M Y') ?? '—'); ?></strong></div>
                    <div><div class="small muted">Gender</div><strong><?php echo e(ucfirst($student->gender ?? '—')); ?></strong></div>
                    <div><div class="small muted">Blood group</div><strong><?php echo e($student->blood_group ?? '—'); ?></strong></div>
                    <div><div class="small muted">Religion</div><strong><?php echo e($student->religion ?? '—'); ?></strong></div>
                    <div><div class="small muted">Phone</div><strong><?php echo e($student->phone ?? '—'); ?></strong></div>
                    <div><div class="small muted">Email</div><strong><?php echo e($student->email ?? '—'); ?></strong></div>
                    <div class="field-span"><div class="small muted">Address</div><strong><?php echo e(collect([$student->address, $student->city, $student->state, $student->postal_code])->filter()->implode(', ') ?: '—'); ?></strong></div>
                    <div><div class="small muted">Admission date</div><strong><?php echo e($student->admission_date?->format('d M Y') ?? '—'); ?></strong></div>
                    <div><div class="small muted">Status</div><span class="badge badge-success"><?php echo e($student->status_label); ?></span></div>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Guardians</h2><p>Primary emergency contacts</p></div></div>
            <div class="list">
                <?php $__empty_1 = true; $__currentLoopData = $student->guardians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guardian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-item">
                        <div>
                            <strong><?php echo e($guardian->name); ?></strong>
                            <small><?php echo e($guardian->relation ?? 'Guardian'); ?><?php echo e($guardian->phone ? ' · '.$guardian->phone : ''); ?><?php echo e($guardian->email ? ' · '.$guardian->email : ''); ?></small>
                            <?php if($guardian->address): ?><small><?php echo e($guardian->address); ?></small><?php endif; ?>
                        </div>
                        <?php if($guardian->is_primary): ?><span class="badge badge-info">Primary</span><?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">No guardian information is recorded.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>Enrollment history</h2><p>Classes and sessions recorded by the school</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Session</th><th>Class</th><th>Section</th><th>Roll</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $student->enrollments->sortByDesc('academic_session_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($enrollment->academicSession?->name); ?></td>
                            <td><?php echo e($enrollment->class?->name); ?></td>
                            <td><?php echo e($enrollment->section?->name ?? '—'); ?></td>
                            <td class="mono"><?php echo e($enrollment->roll_no ?? '—'); ?></td>
                            <td><span class="badge <?php echo e($enrollment->status === 'active' ? 'badge-success' : 'badge-warning'); ?>"><?php echo e(ucfirst($enrollment->status)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty">No enrollment records are available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\student\profile.blade.php ENDPATH**/ ?>