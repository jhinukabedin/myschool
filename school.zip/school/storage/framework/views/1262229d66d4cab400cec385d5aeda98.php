<?php
    $meta = [
        'administration_message' => [
            'title' => 'প্রশাসনের বাণী',
            'eyebrow' => 'প্রশাসন',
            'role' => 'প্রশাসন',
            'fallback' => 'আমাদের বিদ্যালয়ের প্রতিটি কার্যক্রমের কেন্দ্রে রয়েছে শিক্ষার্থী। সুসংগঠিত প্রশাসন, আন্তরিক শিক্ষকমণ্ডলী এবং সচেতন অভিভাবকের সমন্বয়ে আমরা এমন একটি পরিবেশ তৈরি করতে চাই যেখানে প্রতিটি শিক্ষার্থী নিরাপদে শিখতে, প্রশ্ন করতে এবং নিজের সম্ভাবনা বিকশিত করতে পারবে।',
        ],
        'president_message' => [
            'title' => 'সভাপতির বাণী',
            'eyebrow' => 'পরিচালনা পর্ষদ',
            'role' => 'সভাপতি',
            'fallback' => 'শিক্ষা কেবল ভালো ফলাফলের জন্য নয়—এটি একজন মানুষকে দায়িত্বশীল, মানবিক ও আত্মনির্ভর করে গড়ে তোলে। আমাদের বিদ্যালয় জ্ঞান, নৈতিকতা ও দেশপ্রেমের সমন্বয়ে শিক্ষার্থীদের ভবিষ্যতের জন্য প্রস্তুত করতে প্রতিশ্রুতিবদ্ধ।',
        ],
    ][$messageType] ?? [
        'title' => 'বাণী',
        'eyebrow' => 'বিদ্যালয়',
        'role' => 'শিক্ষক',
        'fallback' => '',
    ];
?>

<?php $__env->startSection('title', $message?->title ?: $meta['title']); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / পরিচিতি / বাণী</div><h1><?php echo e($meta['title']); ?></h1><p><?php echo e($siteNameBn); ?> · <?php echo e($meta['eyebrow']); ?></p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <?php if($message): ?>
                <?php if($message->image_url): ?>
                    <img class="message-portrait" src="<?php echo e($message->image_url); ?>" alt="<?php echo e($message->title); ?>">
                <?php endif; ?>
                <h2><?php echo e($message->title); ?></h2>
                <?php if($message->excerpt): ?>
                    <p class="lead-text"><?php echo e($message->excerpt); ?></p>
                <?php endif; ?>
                <div><?php echo $message->body_html; ?></div>
                <p style="margin-top:24px"><b><?php echo e($message->category ?: $meta['role']); ?></b><br><?php echo e($siteNameBn); ?></p>
            <?php elseif($page): ?>
                <h2><?php echo e($page->title); ?></h2>
                <div><?php echo $page->body_html; ?></div>
            <?php else: ?>
                <h2><?php echo e($meta['title']); ?></h2>
                <p><?php echo e($meta['fallback']); ?></p>
                <p style="margin-top:24px"><b><?php echo e($meta['role']); ?></b><br><?php echo e($siteNameBn); ?></p>
            <?php endif; ?>
        </article>

        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">আরও দেখুন</h3>
                <a href="<?php echo e(route('website.about')); ?>" style="display:block;padding:7px 0">বিদ্যালয় পরিচিতি</a>
                <a href="<?php echo e(route('website.administration-message')); ?>" style="display:block;padding:7px 0">প্রশাসনের বাণী</a>
                <a href="<?php echo e(route('website.principal-message')); ?>" style="display:block;padding:7px 0">প্রধান শিক্ষকের বাণী</a>
                <a href="<?php echo e(route('website.president-message')); ?>" style="display:block;padding:7px 0">সভাপতির বাণী</a>
                <a href="<?php echo e(route('website.faculty')); ?>" style="display:block;padding:7px 0">শিক্ষকবৃন্দ</a>
            </div>
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">যোগাযোগ</h3>
                <?php if($siteAddress): ?><p><?php echo e($siteAddress); ?></p><?php endif; ?>
                <?php if($sitePhone): ?><p>ফোন: <?php echo e($sitePhone); ?></p><?php endif; ?>
                <?php if($siteEmail): ?><p>ইমেইল: <?php echo e($siteEmail); ?></p><?php endif; ?>
            </div>
        </aside>
    </div></section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
    <style>
        .message-portrait { max-width: 180px; max-height: 220px; object-fit: cover; border-radius: 12px; float: right; margin: 0 0 18px 24px; }
        .article .lead-text { font-size: 16px; color: var(--navy); font-weight: 600; }
        @media (max-width: 640px) { .message-portrait { float: none; display: block; margin: 0 0 16px; } }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\message.blade.php ENDPATH**/ ?>