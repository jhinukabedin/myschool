<?php $__env->startSection('title', 'Password'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Account security</p>
            <h1>Change password</h1>
            <p>Change the default school password to something only you know. You will stay signed in on this device.</p>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route(auth()->user()->homeRouteName())); ?>">Back to dashboard</a>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head"><div><h2>Update password</h2><p>Minimum 8 characters</p></div></div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('password.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-grid">
                        <div class="field field-span">
                            <label for="current_password">Current password</label>
                            <input id="current_password" name="current_password" type="password" required autocomplete="current-password">
                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:#b42318"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <label for="password">New password</label>
                            <input id="password" name="password" type="password" required autocomplete="new-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:#b42318"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <label for="password_confirmation">Confirm new password</label>
                            <input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password">
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit" style="margin-top:16px">Update password</button>
                </form>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Account</h2><p>Sign-in identity</p></div></div>
            <div class="card-body">
                <p><span class="small muted">Name</span><br><strong><?php echo e(auth()->user()->name); ?></strong></p>
                <p><span class="small muted">Username / student ID</span><br><strong class="mono"><?php echo e(auth()->user()->username ?? '—'); ?></strong></p>
                <p><span class="small muted">Mobile</span><br><strong><?php echo e(auth()->user()->phone ?? '—'); ?></strong></p>
                <p><span class="small muted">Role</span><br><strong><?php echo e(auth()->user()->role?->name ?? '—'); ?></strong></p>
                <div class="alert alert-success" style="margin:14px 0 0">Never share your password. The school office will never ask for it.</div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\password.blade.php ENDPATH**/ ?>