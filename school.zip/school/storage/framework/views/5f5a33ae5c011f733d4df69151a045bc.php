<?php ($nested = $nested ?? false); ?>
<tr>
    <td class="mono"><?php echo e($item->sort_order); ?></td>
    <td>
        <div class="cell-title" style="<?php echo e($nested ? 'padding-left:18px' : ''); ?>">
            <?php if($nested): ?><span class="muted">↳ </span><?php endif; ?><?php echo e($item->title); ?>

        </div>
        <details style="margin-top:4px">
            <summary class="cell-sub" style="cursor:pointer">Edit item</summary>
            <form method="POST" action="<?php echo e(route('website-menus.items.update', $item)); ?>" style="display:grid;gap:6px;margin-top:8px;min-width:230px">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input class="input" name="title" value="<?php echo e($item->title); ?>" required maxlength="120" aria-label="Title">
                <input class="input" name="url" value="<?php echo e($item->url); ?>" placeholder="URL" aria-label="URL">
                <input class="input" name="route_name" value="<?php echo e($item->route_name); ?>" placeholder="Route name" aria-label="Route name">
                <select class="select" name="parent_id" aria-label="Parent">
                    <option value="">Top-level item</option>
                    <?php $__currentLoopData = $menu->rootItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $root): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($root->id !== $item->id): ?>
                            <option value="<?php echo e($root->id); ?>" <?php if($item->parent_id === $root->id): echo 'selected'; endif; ?>><?php echo e($root->title); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div style="display:flex;gap:6px">
                    <input class="input" type="number" min="0" name="sort_order" value="<?php echo e($item->sort_order); ?>" aria-label="Sort order" style="width:90px">
                    <select class="select" name="target" aria-label="Target" style="width:110px">
                        <option value="_self" <?php if($item->target === '_self'): echo 'selected'; endif; ?>>Same tab</option>
                        <option value="_blank" <?php if($item->target === '_blank'): echo 'selected'; endif; ?>>New tab</option>
                    </select>
                </div>
                <input type="hidden" name="is_active" value="0">
                <label class="checkbox"><input type="checkbox" name="is_active" value="1" <?php if($item->is_active): echo 'checked'; endif; ?>> <span>Active</span></label>
                <button class="btn btn-secondary btn-sm" type="submit">Save item</button>
            </form>
        </details>
    </td>
    <td>
        <?php if($item->route_name): ?>
            <code><?php echo e($item->route_name); ?></code>
        <?php else: ?>
            <code><?php echo e($item->url); ?></code>
        <?php endif; ?>
        <?php if($item->target === '_blank'): ?><div class="cell-sub">New tab</div><?php endif; ?>
    </td>
    <td><?php echo e($item->parent?->title ?? '—'); ?></td>
    <td><?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['color' => $item->is_active ? 'success' : 'neutral']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->is_active ? 'success' : 'neutral')]); ?><?php echo e($item->is_active ? 'Active' : 'Hidden'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?></td>
    <td class="actions">
        <form method="POST" action="<?php echo e(route('website-menus.items.destroy', $item)); ?>" onsubmit="return confirm('Delete this item<?php echo e($item->children->isNotEmpty() ? ' and its child items' : ''); ?>?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger btn-sm" type="submit">Delete</button>
        </form>
    </td>
</tr>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\admin\website\_menu-row.blade.php ENDPATH**/ ?>