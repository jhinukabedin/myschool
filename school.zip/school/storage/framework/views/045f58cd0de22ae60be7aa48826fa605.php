<?php $__env->startSection('title', 'Edit Enquiry'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('students.enquiries._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\students\enquiries\edit.blade.php ENDPATH**/ ?>