<?php $__env->startSection('title', 'Downloads'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Resources</p>
            <h1>Downloads</h1>
            <p>Syllabus, forms and other files published by the school for students and guardians.</p>
        </div>
    </div>

    <div class="grid grid-2">
        <?php $__empty_1 = true; $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="card">
                <div class="card-body">
                    <div class="chips" style="margin-bottom:8px">
                        <span class="badge badge-info"><?php echo e($download->category ?: 'Resource'); ?></span>
                        <?php if($download->published_at): ?><span class="badge"><?php echo e($download->published_at->format('d M Y')); ?></span><?php endif; ?>
                    </div>
                    <h2 style="margin:0 0 6px;font-size:17px"><?php echo e($download->title); ?></h2>
                    <p class="muted" style="margin:0 0 14px"><?php echo e($download->excerpt ?: 'Published school document.'); ?></p>
                    <?php if($download->file_url): ?>
                        <a class="btn btn-primary" href="<?php echo e($download->file_url); ?>" target="_blank" rel="noopener">Download file</a>
                    <?php else: ?>
                        <span class="badge badge-warning">File unavailable</span>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card" style="grid-column:1/-1"><div class="empty">No downloads have been published.</div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\downloads.blade.php ENDPATH**/ ?>