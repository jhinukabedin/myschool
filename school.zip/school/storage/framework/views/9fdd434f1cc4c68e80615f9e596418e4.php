<?php $__env->startSection('title', 'Results'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Academic record</p>
            <h1><?php echo e($portalPrefix === 'parent' ? $student->full_name.'\'s Results' : 'My Results'); ?></h1>
            <p>Only examinations published by the school are shown. Grading uses the scheme stored at publication time.</p>
        </div>
        <div class="chips">
            <?php if($enrollment): ?>
                <span class="chip"><?php echo e($enrollment->class?->name); ?> · <?php echo e($enrollment->section?->name ?? 'No section'); ?></span>
            <?php endif; ?>
            <span class="chip"><?php echo e($session?->name ?? 'No session'); ?></span>
        </div>
    </div>

    <?php if($portalPrefix === 'parent' && isset($children) && $children->count() > 1): ?>
        <div class="child-select" aria-label="Select child">
            <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('parent.results.index', $childOption)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $childOption->id === $student->id]); ?>"><?php echo e($childOption->full_name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-3">
        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $result = $row['result'];
                $sheetUrl = $portalPrefix === 'parent'
                    ? route('parent.results.show', [$student, $row['exam']])
                    : route('student.results.show', $row['exam']);
                $badge = in_array($result['result'], ['Pass'], true) ? 'badge-success' : ($result['result'] === 'Fail' ? 'badge-danger' : 'badge-warning');
            ?>
            <article class="card">
                <div class="card-head">
                    <div>
                        <h2><?php echo e($row['exam']->name); ?></h2>
                        <p><?php echo e($row['exam']->academicSession?->name); ?> · published <?php echo e($row['published_at']?->format('d M Y')); ?></p>
                    </div>
                    <span class="badge <?php echo e($badge); ?>"><?php echo e($result['result']); ?></span>
                </div>
                <div class="card-body">
                    <div class="result-summary" style="grid-template-columns:repeat(2,minmax(0,1fr))">
                        <div><span>GPA</span><strong><?php echo e(number_format($result['gpa'], 2)); ?></strong></div>
                        <div><span>Grade</span><strong><?php echo e($result['grade']); ?></strong></div>
                        <div><span>Total</span><strong><?php echo e(number_format($result['total'], 2)); ?> / <?php echo e(number_format($result['full_total'], 0)); ?></strong></div>
                        <div><span>Subjects</span><strong><?php echo e(count($result['subjects'])); ?></strong></div>
                    </div>
                    <div class="chips" style="margin-top:14px">
                        <span class="chip"><?php echo e($row['exam']->exam_type); ?></span>
                        <?php if($row['exam']->gradingScheme): ?><span class="chip"><?php echo e($row['exam']->gradingScheme->name); ?></span><?php endif; ?>
                        <?php if($row['snapshot']): ?><span class="chip chip-success">Archived mark sheet</span><?php endif; ?>
                    </div>
                    <p style="margin:14px 0 0"><a class="btn btn-primary" href="<?php echo e($sheetUrl); ?>">Open result sheet</a></p>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card" style="grid-column:1/-1"><div class="empty">
                <strong>No published results are available.</strong><br>
                Results appear here after the examination controller publishes and locks them. Draft marks are never visible.
            </div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\results\index.blade.php ENDPATH**/ ?>