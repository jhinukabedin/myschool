<?php $__env->startSection('title', 'Result Sheet · '.$student->full_name); ?>

<?php $__env->startSection('content'); ?>
    <div class="print-hide" style="max-width:900px;margin:0 auto 12px;display:flex;justify-content:space-between;align-items:center;gap:8px">
        <a href="<?php echo e($backUrl); ?>" class="btn btn-secondary btn-sm">Back to results</a>
        <span class="muted-2" style="font-size:11px">Published result · use your browser print dialog to save as PDF.</span>
    </div>

    <div class="receipt-sheet" style="max-width:900px">
        <div class="receipt-head">
            <div>
                <div class="receipt-school"><?php echo e(school_name()); ?></div>
                <div class="receipt-sub"><?php echo e(school_setting('school_address')); ?></div>
                <div class="receipt-sub"><?php echo e(school_setting('school_phone')); ?> · <?php echo e(school_setting('school_email')); ?></div>
            </div>
            <div class="receipt-badge">
                <div class="r-title">Academic Result</div>
                <div class="receipt-no"><?php echo e($exam->name); ?></div>
                <div class="receipt-sub"><?php echo e($exam->academicSession?->name); ?> · <?php echo e(ucfirst($exam->exam_type)); ?></div>
            </div>
        </div>

        <div class="receipt-grid">
            <div><div class="receipt-label">Student</div><div class="receipt-value"><?php echo e($student->full_name); ?></div></div>
            <div><div class="receipt-label">Admission No</div><div class="receipt-value"><?php echo e($student->admission_no); ?></div></div>
            <div><div class="receipt-label">Class</div><div class="receipt-value"><?php echo e($enrollment->class?->name); ?></div></div>
            <div><div class="receipt-label">Section / Roll</div><div class="receipt-value"><?php echo e($enrollment->section?->name ?? '—'); ?> / <?php echo e($enrollment->roll_no ?? '—'); ?></div></div>
            <div><div class="receipt-label">Published</div><div class="receipt-value"><?php echo e($published_at?->format('d M Y, h:i A')); ?></div></div>
            <div><div class="receipt-label">Grading scheme</div><div class="receipt-value"><?php echo e($exam->gradingScheme?->name ?? 'Institution default'); ?></div></div>
        </div>

        <table class="receipt-table" style="width:100%;margin-top:18px">
            <thead>
                <tr>
                    <th style="text-align:left">Subject</th>
                    <th>Full marks</th>
                    <th>Pass marks</th>
                    <th>Obtained</th>
                    <th>Grade</th>
                    <th>Grade point</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $result['subjects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align:left">
                            <?php echo e($subjectRow['subject']?->name ?? 'Subject'); ?>

                            <?php if(! empty($subjectRow['components'])): ?>
                                <div class="muted-2" style="font-size:10px;margin-top:2px">
                                    <?php echo e(collect($subjectRow['components'])->map(fn ($component) => $component['name'].': '.($component['obtained'] === null ? '—' : number_format((float) $component['obtained'], 2)).'/'.number_format((float) $component['full_marks'], 0))->implode(' · ')); ?>

                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format($subjectRow['full_marks'], 0)); ?></td>
                        <td><?php echo e(number_format($subjectRow['pass_marks'], 0)); ?></td>
                        <td>
                            <?php if($subjectRow['special_status'] === 'missing'): ?>
                                Not entered
                            <?php elseif($subjectRow['exempt']): ?>
                                Exempt
                            <?php elseif($subjectRow['absent']): ?>
                                Absent
                            <?php else: ?>
                                <?php echo e(number_format((float) $subjectRow['obtained'], 2)); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($subjectRow['grade']); ?></td>
                        <td><?php echo e($subjectRow['grade_point'] === null ? '—' : number_format((float) $subjectRow['grade_point'], 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="receipt-grid" style="margin-top:18px">
            <div><div class="receipt-label">Total marks</div><div class="receipt-value"><?php echo e(number_format($result['total'], 2)); ?> / <?php echo e(number_format($result['full_total'], 2)); ?></div></div>
            <div><div class="receipt-label">Percentage</div><div class="receipt-value"><?php echo e(number_format($result['percentage'], 2)); ?>%</div></div>
            <div><div class="receipt-label">GPA</div><div class="receipt-value"><?php echo e(number_format($result['gpa'], 2)); ?></div></div>
            <div><div class="receipt-label">Grade</div><div class="receipt-value"><?php echo e($result['grade']); ?></div></div>
            <div><div class="receipt-label">Result</div><div class="receipt-value"><?php echo e($result['result']); ?></div></div>
            <div><div class="receipt-label">Failed subjects</div><div class="receipt-value"><?php echo e($result['failed_subjects']); ?></div></div>
        </div>

        <?php if(! empty($result['special_statuses'])): ?>
            <p class="muted-2" style="margin-top:12px;font-size:12px">
                Special status: <?php echo e(collect($result['special_statuses'])->map(fn ($status) => ucfirst($status))->implode(', ')); ?>.
                Contact the examination office for clarification.
            </p>
        <?php endif; ?>

        <div class="receipt-foot" style="margin-top:36px">
            <div>Class Teacher</div>
            <div>Controller of Examinations</div>
            <div>Principal</div>
        </div>
        <p class="muted-2" style="text-align:center;font-size:11px;margin-top:18px">
            This is a computer-generated result sheet. <?php echo e($portalRole ?? 'Portal'); ?> access confirmed by the system audit log.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\results\sheet.blade.php ENDPATH**/ ?>