<?php $__env->startSection('title', 'Result Sheet · '.$student->full_name); ?>

<?php $__env->startSection('content'); ?>
    <div class="receipt-sheet" style="max-width:900px">
        <div class="receipt-head">
            <div>
                <div class="receipt-school"><?php echo e(school_name()); ?></div>
                <div class="receipt-sub"><?php echo e(school_setting('school_address')); ?></div>
                <div class="receipt-sub"><?php echo e(school_setting('school_phone')); ?> · <?php echo e(school_setting('school_email')); ?></div>
            </div>
            <div class="receipt-badge">
                <div class="r-title">Academic Result</div>
                <div class="receipt-no"><?php echo e($exam->name); ?></div>
                <div class="receipt-sub"><?php echo e($exam->academicSession?->name); ?></div>
            </div>
        </div>

        <div class="receipt-grid">
            <div><div class="receipt-label">Student</div><div class="receipt-value"><?php echo e($student->full_name); ?></div></div>
            <div><div class="receipt-label">Admission No</div><div class="receipt-value"><?php echo e($student->admission_no); ?></div></div>
            <div><div class="receipt-label">Class</div><div class="receipt-value"><?php echo e($class->name); ?> · Section <?php echo e($enrollment->section?->name); ?></div></div>
            <div><div class="receipt-label">Roll No</div><div class="receipt-value"><?php echo e($enrollment->roll_no); ?></div></div>
            <div><div class="receipt-label">Examination</div><div class="receipt-value"><?php echo e($exam->name); ?></div></div>
            <div><div class="receipt-label">Result Date</div><div class="receipt-value"><?php echo e($exam->end_date?->format('d M Y')); ?></div></div>
        </div>

        <table class="receipt-table">
            <thead>
                <tr><th>Subject</th><th style="text-align:right">Full Marks</th><th style="text-align:right">Pass Marks</th><th style="text-align:right">Obtained</th><th>Grade</th><th style="text-align:right">Grade Point</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $result['subjects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($row['subject']?->name); ?>

                            <?php if(! empty($row['components'])): ?>
                                <div style="font-size:10px;color:#6b7280;margin-top:2px">
                                    <?php echo e(collect($row['components'])->map(fn ($component) => $component['name'].': '.($component['obtained'] === null ? '—' : number_format((float) $component['obtained'], 2)).'/'.number_format((float) $component['full_marks'], 0))->implode(' · ')); ?>

                                </div>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:right"><?php echo e(number_format($row['full_marks'], 2)); ?></td>
                        <td style="text-align:right"><?php echo e(number_format($row['pass_marks'], 2)); ?></td>
                        <td style="text-align:right"><?php echo e($row['absent'] ? 'Absent' : number_format($row['obtained'], 2)); ?></td>
                        <td><?php echo e($row['grade']); ?></td>
                        <td style="text-align:right"><?php echo e(number_format($row['grade_point'], 2)); ?></td>
                        <td><span style="color:<?php echo e($row['passed'] ? '#047857' : '#b91c1c'); ?>;font-weight:700"><?php echo e($row['passed'] ? 'Pass' : 'Fail'); ?></span></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="receipt-grid" style="padding-top:18px">
            <div><div class="receipt-label">Total Marks</div><div class="receipt-value"><?php echo e(number_format($result['total'], 2)); ?> / <?php echo e(number_format($result['full_total'], 2)); ?></div></div>
            <div><div class="receipt-label">Percentage</div><div class="receipt-value"><?php echo e(number_format($result['percentage'], 2)); ?>%</div></div>
            <div><div class="receipt-label">GPA</div><div class="receipt-value"><?php echo e(number_format($result['gpa'], 2)); ?></div></div>
            <div><div class="receipt-label">Grade</div><div class="receipt-value"><?php echo e($result['grade']); ?></div></div>
            <div><div class="receipt-label">Failed Subjects</div><div class="receipt-value"><?php echo e($result['failed_subjects']); ?></div></div>
            <div><div class="receipt-label">Final Result</div><div class="receipt-value" style="color:<?php echo e($result['result'] === 'Pass' ? '#047857' : '#b91c1c'); ?>;font-weight:800"><?php echo e(strtoupper($result['result'])); ?></div></div>
        </div>

        <div class="receipt-total">Final Result: <?php echo e($result['result']); ?> · GPA <?php echo e(number_format($result['gpa'], 2)); ?></div>

        <div class="receipt-footer">
            <div>Generated <?php echo e(now()->format('d M Y, h:i A')); ?> by <?php echo e(auth()->user()?->name ?? 'System'); ?></div>
            <div class="signature"><div class="signature-line">Class Teacher</div></div>
            <div class="signature"><div class="signature-line">Principal</div></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\academics\results\sheet.blade.php ENDPATH**/ ?>