<?php $__env->startSection('title', 'ইভেন্ট'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / ইভেন্ট</div><h1>ইভেন্ট</h1><p>আসন্ন ও সাম্প্রতিক অনুষ্ঠান</p></div></section>

    <section class="section"><div class="container">
        <div class="academic-grid" style="grid-template-columns:repeat(2,1fr)">
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="card article reveal">
                    <?php if($item->image_url): ?><img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->title); ?>" style="width:100%;height:170px;object-fit:cover;border-radius:8px;margin-bottom:12px"><?php endif; ?>
                    <span class="badge gold"><?php echo e($item->category ?: 'ইভেন্ট'); ?></span>
                    <h3 style="margin-top:8px"><?php echo e($item->title); ?></h3>
                    <small class="muted"><?php echo e($item->published_at?->format('d M Y')); ?></small>
                    <p><?php echo e($item->excerpt ?: Str::limit(strip_tags($item->body), 180)); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card article" style="grid-column:1/-1"><p>বর্তমানে কোনো প্রকাশিত ইভেন্ট নেই।</p></div>
            <?php endif; ?>
        </div>
        <div style="margin-top:16px"><?php echo e($items->links()); ?></div>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\events.blade.php ENDPATH**/ ?>