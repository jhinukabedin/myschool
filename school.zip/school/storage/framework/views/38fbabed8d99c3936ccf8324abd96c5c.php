<?php $__env->startSection('title', 'প্রধান শিক্ষকের বাণী'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / পরিচিতি / বাণী</div><h1>প্রধান শিক্ষকের বাণী</h1><p>আমাদের শিক্ষার্থী ও অভিভাবকদের প্রতি</p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <?php if($message): ?>
                <?php if($message->image_url): ?>
                    <img class="message-portrait" src="<?php echo e($message->image_url); ?>" alt="<?php echo e($message->title); ?>">
                <?php endif; ?>
                <h2><?php echo e($message->title); ?></h2>
                <?php if($message->excerpt): ?><p class="lead-text"><?php echo e($message->excerpt); ?></p><?php endif; ?>
                <div><?php echo $message->body_html; ?></div>
                <p style="margin-top:20px"><b><?php echo e($message->category ?: 'প্রধান শিক্ষক'); ?></b><br><?php echo e($siteNameBn); ?></p>
            <?php elseif($page): ?>
                <h2><?php echo e($page->title); ?></h2>
                <div><?php echo $page->body_html; ?></div>
            <?php else: ?>
                <h2>শিক্ষার্থীর সম্ভাবনাকে বিকশিত করাই আমাদের লক্ষ্য</h2>
                <p>প্রিয় শিক্ষার্থী ও অভিভাবকবৃন্দ,</p>
                <p>প্রতিটি শিক্ষার্থীর ভেতরে আলাদা সম্ভাবনা রয়েছে। সঠিক দিকনির্দেশনা, অধ্যবসায় ও সুন্দর পরিবেশের মাধ্যমে সেই সম্ভাবনাকে বিকশিত করাই আমাদের প্রধান লক্ষ্য। <?php echo e($siteNameBn); ?>-এ আমরা শুধু পরীক্ষার ফলাফল নয়, বরং একজন দায়িত্বশীল, মানবিক ও আত্মনির্ভর মানুষ গড়ে তুলতে বিশ্বাস করি।</p>
                <p>আমাদের অভিজ্ঞ শিক্ষকমণ্ডলী, সুশৃঙ্খল একাডেমিক কার্যক্রম এবং সহশিক্ষা কার্যক্রমের মাধ্যমে শিক্ষার্থীদের সর্বাঙ্গীণ বিকাশে আমরা প্রতিশ্রুতিবদ্ধ। অভিভাবকদের সক্রিয় সহযোগিতা এই যাত্রাকে আরও শক্তিশালী করে।</p>
                <p>আমি সকল শিক্ষার্থীর উজ্জ্বল ভবিষ্যৎ কামনা করি।</p>
                <p style="margin-top:20px"><b>প্রধান শিক্ষক</b><br><?php echo e($siteNameBn); ?></p>
            <?php endif; ?>
        </article>
        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">আরও দেখুন</h3>
                <a href="<?php echo e(route('website.about')); ?>" style="display:block;padding:7px 0">বিদ্যালয় পরিচিতি</a>
                <a href="<?php echo e(route('website.administration-message')); ?>" style="display:block;padding:7px 0">প্রশাসনের বাণী</a>
                <a href="<?php echo e(route('website.president-message')); ?>" style="display:block;padding:7px 0">সভাপতির বাণী</a>
                <a href="<?php echo e(route('website.faculty')); ?>" style="display:block;padding:7px 0">শিক্ষকবৃন্দ</a>
                <a href="<?php echo e(route('website.admission')); ?>" style="display:block;padding:7px 0">ভর্তি তথ্য</a>
            </div>
        </aside>
    </div></section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>
    <style>
        .message-portrait { max-width: 180px; max-height: 220px; object-fit: cover; border-radius: 12px; float: right; margin: 0 0 18px 24px; }
        .article .lead-text { font-size: 16px; color: var(--navy); font-weight: 600; }
        @media (max-width: 640px) { .message-portrait { float: none; display: block; margin: 0 0 16px; } }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\principal-message.blade.php ENDPATH**/ ?>