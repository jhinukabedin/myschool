<?php $__env->startSection('title', 'Media Library'); ?>

<?php $__env->startPush('head'); ?>
    <style>
        .media-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 14px; padding: 16px; }
        .media-card { border: 1px solid var(--border); border-radius: 12px; overflow: hidden; background: #fff; display: flex; flex-direction: column; }
        .media-thumb { aspect-ratio: 4 / 3; background: #f1f5f9; display: grid; place-items: center; overflow: hidden; border: 0; padding: 0; width: 100%; cursor: zoom-in; }
        .media-thumb img { width: 100%; height: 100%; object-fit: cover; }
        .media-file { width: 54px; height: 64px; border-radius: 8px; background: #e8eef7; color: #385d79; display: grid; place-items: center; font-weight: 800; font-size: 11px; text-transform: uppercase; }
        .media-info { padding: 10px 12px; display: grid; gap: 3px; }
        .media-info strong { font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .media-info small { color: #667085; font-size: 11px; }
        .media-actions { display: flex; gap: 5px; flex-wrap: wrap; padding: 0 12px 12px; margin-top: auto; }
        .media-actions .btn { font-size: 11px; padding: 4px 7px; }
        .media-meta { border-top: 1px solid var(--border); padding: 8px 12px; font-size: 11px; }
        .media-meta summary { cursor: pointer; color: #667085; }
        .media-meta form { display: grid; gap: 6px; margin-top: 8px; }
        .media-meta input { width: 100%; font-size: 12px; padding: 6px 8px; }
        dialog.lightbox { border: 0; padding: 0; background: transparent; max-width: min(1100px, 94vw); max-height: 92vh; }
        dialog.lightbox::backdrop { background: rgba(5, 12, 24, .82); }
        .lightbox-inner { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 30px 80px rgba(0,0,0,.35); }
        .lightbox-inner img { display: block; max-width: 100%; max-height: 78vh; margin: 0 auto; background: #0b1220; }
        .lightbox-bar { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 10px 14px; font-size: 12px; }
        .lightbox-bar button { border: 0; background: var(--danger, #b42318); color: #fff; border-radius: 7px; padding: 6px 10px; cursor: pointer; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['eyebrow' => 'Website','title' => 'Media Library','subtitle' => 'Upload, preview and safely remove images and documents used by the public website.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Website','title' => 'Media Library','subtitle' => 'Upload, preview and safely remove images and documents used by the public website.']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => route('website-content.index'),'variant' => 'secondary','icon' => 'layout-dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('website-content.index')),'variant' => 'secondary','icon' => 'layout-dashboard']); ?>Content library <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

    <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.website._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="grid-2">
        <div class="card">
            <div class="card-header"><div><h3 class="card-title">Upload media</h3><p class="card-sub">Up to 20 files at once, 10 MB each. Images, PDFs, Office documents and archives.</p></div></div>
            <form method="POST" action="<?php echo e(route('media.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-section">
                    <div class="form-grid">
                        <div class="span-2"><?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'files[]','label' => 'Files','type' => 'file','multiple' => true,'required' => true,'accept' => 'image/jpeg,image/png,image/webp,image/gif,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'files[]','label' => 'Files','type' => 'file','multiple' => true,'required' => true,'accept' => 'image/jpeg,image/png,image/webp,image/gif,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?></div>
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'category','label' => 'Category','placeholder' => 'Gallery, Notice, Academic']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category','label' => 'Category','placeholder' => 'Gallery, Notice, Academic']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'alt_text','label' => 'Default alt text','placeholder' => 'Describe the image for accessibility']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alt_text','label' => 'Default alt text','placeholder' => 'Describe the image for accessibility']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="card-footer" style="display:flex;justify-content:flex-end">
                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','variant' => 'primary','icon' => 'upload']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary','icon' => 'upload']); ?>Upload files <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card">
            <div class="card-header"><div><h3 class="card-title">Storage safety</h3><p class="card-sub">Deletion rules</p></div></div>
            <div class="card-body">
                <div class="warning-box" style="margin-bottom:12px">A file used by website content or site settings cannot be deleted from the media library. Replace the reference first.</div>
                <p class="muted" style="font-size:12px;margin:0">Test the public page after replacing a file. The library tracks disk path, MIME type, dimensions and uploader for every file.</p>
            </div>
        </div>
    </div>

    <div class="card" style="margin-top:18px">
        <div class="card-header">
            <div><h3 class="card-title">Files</h3><p class="card-sub"><?php echo e($media->total()); ?> file(s)</p></div>
            <form method="GET" action="<?php echo e(route('media.index')); ?>" class="filter-bar" style="margin:0;flex-wrap:wrap">
                <div class="field"><input class="input" type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search name or alt text"></div>
                <div class="field">
                    <select class="select" name="kind">
                        <option value="">Any kind</option>
                        <option value="image" <?php if(request('kind') === 'image'): echo 'selected'; endif; ?>>Images</option>
                        <option value="application" <?php if(request('kind') === 'application'): echo 'selected'; endif; ?>>Documents</option>
                    </select>
                </div>
                <div class="field">
                    <select class="select" name="category">
                        <option value="">Any category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category); ?>" <?php if(request('category') === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','variant' => 'secondary','icon' => 'filter']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'secondary','icon' => 'filter']); ?>Filter <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </form>
        </div>

        <div class="media-grid">
            <?php $__empty_1 = true; $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="media-card">
                    <?php if($file->isImage()): ?>
                        <button type="button" class="media-thumb" data-media-preview data-url="<?php echo e($file->url); ?>" data-title="<?php echo e($file->original_name); ?>" data-caption="<?php echo e($file->caption); ?>">
                            <img src="<?php echo e($file->url); ?>" alt="<?php echo e($file->alt_text ?: $file->original_name); ?>" loading="lazy">
                        </button>
                    <?php else: ?>
                        <div class="media-thumb" style="cursor:default"><span class="media-file"><?php echo e($file->extension ?: 'FILE'); ?></span></div>
                    <?php endif; ?>
                    <div class="media-info">
                        <strong title="<?php echo e($file->original_name); ?>"><?php echo e($file->original_name); ?></strong>
                        <small><?php echo e($file->human_size); ?><?php if($file->width): ?> · <?php echo e($file->width); ?>×<?php echo e($file->height); ?><?php endif; ?></small>
                        <small><?php echo e($file->category ?: 'Uncategorised'); ?> · <?php echo e($file->created_at?->format('d M Y')); ?></small>
                    </div>
                    <div class="media-actions">
                        <a class="btn btn-secondary" href="<?php echo e($file->url); ?>" target="_blank" rel="noopener">Open</a>
                        <button type="button" class="btn btn-secondary" data-copy="<?php echo e($file->path); ?>">Copy path</button>
                        <form method="POST" action="<?php echo e(route('media.destroy', $file)); ?>" onsubmit="return confirm('Delete this file? It will fail safely if content still references it.')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </div>
                    <details class="media-meta">
                        <summary>Edit metadata</summary>
                        <form method="POST" action="<?php echo e(route('media.update', $file)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input name="alt_text" value="<?php echo e($file->alt_text); ?>" placeholder="Alt text" maxlength="255">
                            <input name="caption" value="<?php echo e($file->caption); ?>" placeholder="Caption" maxlength="500">
                            <input name="category" value="<?php echo e($file->category); ?>" placeholder="Category" maxlength="80">
                            <button class="btn btn-secondary btn-sm" type="submit">Save</button>
                        </form>
                    </details>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state" style="grid-column:1/-1">No media files have been uploaded.</div>
            <?php endif; ?>
        </div>
        <div class="card-footer"><?php echo e($media->links()); ?></div>
    </div>

    <dialog class="lightbox" id="media-lightbox">
        <div class="lightbox-inner">
            <img id="lightbox-image" src="" alt="">
            <div class="lightbox-bar">
                <span id="lightbox-caption"></span>
                <button type="button" onclick="document.getElementById('media-lightbox').close()">Close</button>
            </div>
        </div>
    </dialog>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const dialog = document.getElementById('media-lightbox');
            const image = document.getElementById('lightbox-image');
            const caption = document.getElementById('lightbox-caption');

            document.querySelectorAll('[data-media-preview]').forEach((button) => {
                button.addEventListener('click', () => {
                    image.src = button.dataset.url;
                    image.alt = button.dataset.title || '';
                    caption.textContent = [button.dataset.title, button.dataset.caption].filter(Boolean).join(' · ');
                    dialog.showModal();
                });
            });

            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) dialog.close();
            });

            document.querySelectorAll('[data-copy]').forEach((button) => {
                button.addEventListener('click', async () => {
                    try {
                        await navigator.clipboard.writeText(button.dataset.copy);
                        const label = button.textContent;
                        button.textContent = 'Copied';
                        setTimeout(() => { button.textContent = label; }, 1200);
                    } catch (error) {
                        window.prompt('Copy this media path', button.dataset.copy);
                    }
                });
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\admin\website\media.blade.php ENDPATH**/ ?>