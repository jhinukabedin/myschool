<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Print'); ?> — <?php echo e($schoolSettings['name'] ?? config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
    <div class="print-page">
        <div class="print-hide" style="max-width:900px;margin:0 auto 12px;display:flex;justify-content:flex-end;gap:8px">
            <button type="button" class="btn btn-secondary" onclick="window.close()">Close</button>
            <button type="button" class="btn btn-primary" onclick="window.print()">Print</button>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\layouts\print.blade.php ENDPATH**/ ?>