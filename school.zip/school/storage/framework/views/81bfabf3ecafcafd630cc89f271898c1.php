<?php
    $portalUser = auth()->user();
    $portalRole = $portalUser?->role?->slug;
    $portalName = match ($portalRole) {
        'student' => 'Student Portal',
        'parent' => 'Parent Portal',
        'teacher' => 'Teacher Portal',
        default => 'School Portal',
    };
    $portalNav = match ($portalRole) {
        'student' => [
            ['label' => 'Dashboard', 'route' => 'student.dashboard', 'active' => 'student.dashboard'],
            ['label' => 'Results', 'route' => 'student.results', 'active' => 'student.results*'],
            ['label' => 'Fees & Payments', 'route' => 'student.fees', 'active' => 'student.fees|student.payments.*'],
            ['label' => 'Attendance', 'route' => 'student.attendance', 'active' => 'student.attendance'],
            ['label' => 'Downloads', 'route' => 'student.downloads', 'active' => 'student.downloads'],
            ['label' => 'My Profile', 'route' => 'student.profile', 'active' => 'student.profile'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        'parent' => [
            ['label' => 'Dashboard', 'route' => 'parent.dashboard', 'active' => 'parent.dashboard'],
            ['label' => 'My Profile', 'route' => 'parent.profile', 'active' => 'parent.profile'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        'teacher' => [
            ['label' => 'My Teaching', 'route' => 'teacher.dashboard', 'active' => 'teacher.dashboard'],
            ['label' => 'Marks Entry', 'route' => 'exams.marks-entry', 'active' => 'exams.marks-entry'],
            ['label' => 'Attendance', 'route' => 'attendance.index', 'active' => 'attendance.index'],
            ['label' => 'Exam Schedule', 'route' => 'exams.schedule', 'active' => 'exams.schedule'],
            ['label' => 'Password', 'route' => 'password.change', 'active' => 'password.*'],
        ],
        default => [],
    };
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', $portalName); ?> · <?php echo e(school_setting('website_name_en', 'Adarsha High School')); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('portal/style.css')); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
<a class="skip-link" href="#portal-main">Skip to content</a>
<header class="portal-header">
    <div class="portal-wrap header-inner">
        <a class="portal-brand" href="<?php echo e(route($portalUser?->homeRouteName() ?? 'website.home')); ?>">
            <span class="brand-mark"><?php echo e(school_setting('website_logo_mark', 'HS')); ?></span>
            <span>
                <strong><?php echo e(school_setting('website_name_bn', 'আদর্শ উচ্চ বিদ্যালয়')); ?></strong>
                <small><?php echo e($portalName); ?></small>
            </span>
        </a>
        <div class="header-meta">
            <span class="session-pill">Session <?php echo e(current_session()?->name ?? '—'); ?></span>
            <span class="user-pill"><?php echo e($portalUser?->name); ?><small><?php echo e($portalName); ?></small></span>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-ghost">Sign out</button>
            </form>
        </div>
    </div>
</header>
<nav class="portal-nav" aria-label="Portal navigation">
    <div class="portal-wrap nav-inner">
        <?php $__currentLoopData = $portalNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs($item['active'])]); ?>"><?php echo e($item['label']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('website.home')); ?>" class="nav-link nav-link-external">School website ↗</a>
    </div>
</nav>

<main id="portal-main" class="portal-wrap portal-main">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-error" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-error" role="alert">
            <strong>Please correct the following:</strong>
            <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="portal-footer">
    <div class="portal-wrap footer-inner">
        <span>© <?php echo e(now()->format('Y')); ?> <?php echo e(school_setting('school_name', 'School')); ?>. All rights reserved.</span>
        <a href="<?php echo e(route('website.privacy')); ?>">Privacy</a>
    </div>
</footer>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\layouts\portal.blade.php ENDPATH**/ ?>