<?php $__env->startSection('title', 'ডাউনলোড'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / ডাউনলোড</div><h1>ডাউনলোড</h1><p>সিলেবাস, ফরম ও গুরুত্বপূর্ণ ফাইল</p></div></section>

    <section class="section"><div class="container">
        <div class="card article">
            <h2>ফাইলসমূহ</h2>
            <div class="download-list">
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 5px;border-bottom:1px solid #e8ecf1;gap:12px">
                        <div>
                            <strong><?php echo e($item->title); ?></strong>
                            <?php if($item->excerpt): ?><div class="muted" style="font-size:13px"><?php echo e($item->excerpt); ?></div><?php endif; ?>
                            <?php if($item->category): ?><span class="badge"><?php echo e($item->category); ?></span><?php endif; ?>
                        </div>
                        <?php if($item->file_url): ?>
                            <a class="btn btn-outline btn-sm" href="<?php echo e($item->file_url); ?>" target="_blank" rel="noopener">ডাউনলোড</a>
                        <?php else: ?>
                            <span class="badge">শীঘ্রই</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>বর্তমানে কোনো ফাইল প্রকাশ করা হয়নি।</p>
                <?php endif; ?>
            </div>
            <div style="margin-top:16px"><?php echo e($items->links()); ?></div>
        </div>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\downloads.blade.php ENDPATH**/ ?>