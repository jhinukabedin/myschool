<?php $__env->startSection('title', 'নোটিশ বোর্ড'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / নোটিশ</div><h1>নোটিশ বোর্ড</h1><p>সর্বশেষ ঘোষণা ও তথ্য</p></div></section>

    <section class="section"><div class="container">
        <div class="card article">
            <div class="section-head" style="margin-bottom:6px">
                <h2 style="margin:0">সকল নোটিশ</h2>
                <form method="GET" action="<?php echo e(route('website.notices')); ?>" style="display:flex;gap:8px">
                    <input class="input" type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="নোটিশ খুঁজুন" style="border:1px solid #dbe1e8;border-radius:8px;padding:9px 11px">
                    <button class="btn btn-outline" type="submit">খুঁজুন</button>
                </form>
            </div>

            <div class="timeline" style="margin-top:18px">
                <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="timeline-item">
                        <small><?php echo e($notice->publish_at?->format('d M Y') ?? $notice->created_at?->format('d M Y')); ?></small>
                        <b><a href="<?php echo e(route('website.notice', $notice)); ?>"><?php echo e($notice->title); ?></a></b>
                        <p style="margin:4px 0 0"><?php echo e(Str::limit(strip_tags($notice->body), 140)); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>বর্তমানে কোনো প্রকাশিত নোটিশ নেই।</p>
                <?php endif; ?>
            </div>

            <div style="margin-top:16px"><?php echo e($notices->links()); ?></div>
        </div>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\notices.blade.php ENDPATH**/ ?>