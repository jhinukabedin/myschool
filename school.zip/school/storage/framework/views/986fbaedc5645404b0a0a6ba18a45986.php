<?php $__env->startSection('title', $item->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / সংবাদ</div><h1><?php echo e($item->title); ?></h1><p><?php echo e($item->published_at?->format('d M Y')); ?></p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <?php if($item->image_url): ?><img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->title); ?>" style="width:100%;max-height:360px;object-fit:cover;border-radius:8px;margin-bottom:16px"><?php endif; ?>
            <?php if($item->excerpt): ?><p style="font-size:17px;color:#3f4c5b"><strong><?php echo e($item->excerpt); ?></strong></p><?php endif; ?>
            <div><?php echo $item->body_html; ?></div>
            <hr style="border:0;border-top:1px solid #edf0f4;margin:22px 0">
            <a class="btn btn-outline" href="<?php echo e(route('website.news')); ?>">← সব সংবাদ</a>
        </article>
        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">আরও সংবাদ</h3>
                <?php $__empty_1 = true; $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('website.news.item', $other->slug)); ?>" style="display:block;padding:6px 0"><?php echo e($other->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>আর কোনো সংবাদ নেই।</p>
                <?php endif; ?>
            </div>
        </aside>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\news-item.blade.php ENDPATH**/ ?>