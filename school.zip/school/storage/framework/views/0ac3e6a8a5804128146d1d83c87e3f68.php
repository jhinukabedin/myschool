<?php $__env->startSection('title', 'Attendance'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Daily attendance</p>
            <h1><?php echo e($portalRole === 'parent' ? $student->full_name.'\'s Attendance' : 'My Attendance'); ?></h1>
            <p>Attendance marked by teachers for <?php echo e($session?->name ?? 'the current session'); ?>. Contact the class teacher if a record looks wrong.</p>
        </div>
        <?php if(isset($children) && $children->count() > 1): ?>
            <div class="selector-form">
                <div class="field">
                    <label for="child-switch">Child</label>
                    <select id="child-switch" onchange="if(this.value) window.location.href=this.value">
                        <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(route('parent.attendance.index', $childOption)); ?>" <?php if($childOption->id === $student->id): echo 'selected'; endif; ?>><?php echo e($childOption->full_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="metric-grid">
        <div class="card stat"><div class="stat-label">Attendance rate</div><div class="stat-value"><?php echo e(number_format($attendance['percentage'], 1)); ?>%</div><div class="stat-meta">Present or late</div></div>
        <div class="card stat"><div class="stat-label">Present</div><div class="stat-value" style="color:var(--success)"><?php echo e($attendance['present']); ?></div><div class="stat-meta"><?php echo e($attendance['records']); ?> marked days</div></div>
        <div class="card stat"><div class="stat-label">Absent</div><div class="stat-value" style="color:var(--danger)"><?php echo e($attendance['absent']); ?></div><div class="stat-meta">Unexcused absence</div></div>
        <div class="card stat"><div class="stat-label">Late / excused</div><div class="stat-value"><?php echo e($attendance['late']); ?> / <?php echo e($attendance['excused']); ?></div><div class="stat-meta">Recorded separately</div></div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="receipt-row" style="margin-bottom:8px"><strong>Overall attendance</strong><span class="mono"><?php echo e(number_format($attendance['percentage'], 1)); ?>%</span></div>
            <div class="progress"><span style="width: <?php echo e(min(100, $attendance['percentage'])); ?>%"></span></div>
            <p class="small muted" style="margin:9px 0 0">
                <?php if($enrollment): ?>
                    <?php echo e($enrollment->class?->name); ?> · Section <?php echo e($enrollment->section?->name ?? '—'); ?> · Roll <?php echo e($enrollment->roll_no ?? '—'); ?>

                <?php else: ?>
                    No current enrollment is recorded.
                <?php endif; ?>
            </p>
        </div>
    </div>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>Recent attendance</h2><p>The latest 10 marked days</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Date</th><th>Class</th><th>Status</th><th>Note</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $attendance['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="mono"><?php echo e($record->attendance_date?->format('d M Y')); ?></td>
                            <td><?php echo e($record->class?->name); ?></td>
                            <td>
                                <span class="badge <?php echo e($record->status === 'present' ? 'badge-success' : ($record->status === 'absent' ? 'badge-danger' : 'badge-warning')); ?>"><?php echo e(ucfirst($record->status)); ?></span>
                            </td>
                            <td class="muted"><?php echo e($record->note ?? '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="empty">No attendance has been marked.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\attendance\index.blade.php ENDPATH**/ ?>