<?php $__env->startSection('title', 'Receipt '.$payment->receipt_no); ?>

<?php $__env->startSection('content'); ?>
    <?php ($enrollment = $payment->student?->enrollments->firstWhere('academic_session_id', $payment->academic_session_id)); ?>

    <div class="print-hide" style="max-width:760px;margin:0 auto 12px;display:flex;justify-content:space-between;align-items:center;gap:8px">
        <a href="<?php echo e(route('fees.collection.show', $payment->student)); ?>" class="btn btn-secondary btn-sm">Back to collection</a>
        <span class="muted-2" style="font-size:11px">Use your browser print dialog to save as PDF.</span>
    </div>

    <div class="receipt-sheet">
        <div class="receipt-head">
            <div>
                <div class="receipt-school"><?php echo e($schoolSettings['name'] ?? 'EduSphere School'); ?></div>
                <div class="receipt-sub"><?php echo e($schoolSettings['address'] ?? ''); ?></div>
                <div class="receipt-sub">
                    <?php echo e($schoolSettings['phone'] ?? ''); ?><?php echo e(! empty($schoolSettings['email']) ? ' · '.$schoolSettings['email'] : ''); ?>

                </div>
            </div>
            <div class="receipt-badge">
                <div class="r-title">Fee receipt</div>
                <div class="receipt-no"><?php echo e($payment->receipt_no); ?></div>
                <div class="receipt-sub"><?php echo e($payment->paid_at?->format('d M Y, h:i A')); ?></div>
            </div>
        </div>

        <?php if($payment->status === 'reversed'): ?>
            <div style="margin-top:16px;padding:10px 12px;border:1px solid #fecaca;background:#fef2f2;color:#991b1b;border-radius:8px;font-size:11px">
                <strong>Reversed payment.</strong>
                This receipt is retained for audit. It is not counted as collected revenue.
                <?php $__currentLoopData = $payment->reversals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reversal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="margin-top:4px"><?php echo e(ucfirst($reversal->type)); ?> on <?php echo e($reversal->reversed_at?->format('d M Y, h:i A')); ?> by <?php echo e($reversal->reversedBy?->name ?? 'System'); ?> — <?php echo e($reversal->reason); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="receipt-grid">
            <div><div class="receipt-label">Student</div><div class="receipt-value"><?php echo e($payment->student?->full_name); ?></div></div>
            <div><div class="receipt-label">Admission number</div><div class="receipt-value"><?php echo e($payment->student?->admission_no); ?></div></div>
            <div><div class="receipt-label">Class</div><div class="receipt-value"><?php echo e($enrollment?->class?->name ?? '—'); ?><?php echo e($enrollment?->section ? ' · '.$enrollment->section->name : ''); ?></div></div>
            <div><div class="receipt-label">Academic session</div><div class="receipt-value"><?php echo e($payment->academicSession?->name); ?></div></div>
            <div><div class="receipt-label">Payment method</div><div class="receipt-value"><?php echo e($payment->method_label); ?></div></div>
            <div><div class="receipt-label">Reference</div><div class="receipt-value"><?php echo e($payment->reference_no ?? '—'); ?></div></div>
        </div>

        <table class="receipt-table">
            <thead><tr><th>Fee head</th><th>Period</th><th style="text-align:right">Amount</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $payment->allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($allocation->assignment?->category?->name ?? 'Fee'); ?></td>
                        <td><?php echo e($allocation->assignment?->period ?? 'One-time'); ?></td>
                        <td style="text-align:right"><?php echo e(money($allocation->amount)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="receipt-total">Total paid: <?php echo e(money($payment->amount)); ?></div>

        <div style="display:flex;justify-content:space-between;gap:16px;margin-top:16px;font-size:10.5px;color:#6b7280">
            <div>Received by: <strong><?php echo e($payment->receivedBy?->name ?? 'System'); ?></strong></div>
            <div>Status: <strong style="color:<?php echo e($payment->status === 'completed' ? '#047857' : '#b91c1c'); ?>"><?php echo e(strtoupper($payment->status)); ?></strong></div>
        </div>

        <?php if($payment->note): ?>
            <div style="margin-top:12px;font-size:10.5px;color:#4b5563"><strong>Note:</strong> <?php echo e($payment->note); ?></div>
        <?php endif; ?>

        <div class="receipt-footer">
            <div><?php echo e($schoolSettings['currency'] ?? '৳'); ?> <?php echo e(number_format((float) $payment->amount, 2)); ?> received with thanks. This is a computer-generated receipt.</div>
            <div class="signature">
                <div class="signature-line">Authorised signature</div>
            </div>
        </div>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fees.reverse')): ?>
        <?php if($payment->status === 'completed'): ?>
            <div class="print-hide" style="max-width:760px;margin:14px auto 0">
                <div class="card">
                    <div class="card-header"><div><h3 class="card-title">Reverse this payment</h3><p class="card-sub">The receipt stays in the ledger; the allocation is released and the balance recalculated.</p></div></div>
                    <form method="POST" action="<?php echo e(route('payments.reverse', $payment)); ?>" onsubmit="return confirm('Reverse this payment? This cannot be undone and is recorded in the audit log.')">
                        <?php echo csrf_field(); ?>
                        <div class="form-section">
                            <div class="form-grid">
                                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'type','label' => 'Reversal type','options' => ['cancellation' => 'Cancellation', 'refund' => 'Refund'],'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','label' => 'Reversal type','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['cancellation' => 'Cancellation', 'refund' => 'Refund']),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'reason','label' => 'Reason','required' => true,'placeholder' => 'Why is this payment being reversed?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'reason','label' => 'Reason','required' => true,'placeholder' => 'Why is this payment being reversed?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <div class="form-section" style="display:flex;justify-content:flex-end">
                            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','variant' => 'danger','icon' => 'rotate-ccw']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'danger','icon' => 'rotate-ccw']); ?>Reverse payment <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\fees\receipt.blade.php ENDPATH**/ ?>