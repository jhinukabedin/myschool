<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'subtitle' => null, 'padding' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'subtitle' => null, 'padding' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'card'])); ?>>
    <?php if($title || isset($actions)): ?>
        <div class="card-header">
            <div>
                <?php if($title): ?><h3 class="card-title"><?php echo e($title); ?></h3><?php endif; ?>
                <?php if($subtitle): ?><p class="card-sub"><?php echo e($subtitle); ?></p><?php endif; ?>
            </div>
            <?php if(isset($actions)): ?>
                <div class="page-actions"><?php echo e($actions); ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($padding): ?>
        <div class="card-body"><?php echo e($slot); ?></div>
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\components\card.blade.php ENDPATH**/ ?>