<?php $__env->startSection('title', 'Student Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Student portal</p>
            <h1>Welcome, <?php echo e($student->first_name); ?></h1>
            <p>Your academic, attendance and fee information for <?php echo e($session?->name ?? 'the current session'); ?>.</p>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route('student.results')); ?>">View all results</a>
    </div>

    <div class="card profile-strip" style="margin-bottom:18px">
        <div class="avatar">
            <?php if($student->photo_url): ?>
                <img src="<?php echo e($student->photo_url); ?>" alt="<?php echo e($student->full_name); ?>">
            <?php else: ?>
                <?php echo e(Str::upper(Str::substr($student->first_name, 0, 1).Str::substr($student->last_name, 0, 1))); ?>

            <?php endif; ?>
        </div>
        <div>
            <h2><?php echo e($student->full_name); ?></h2>
            <div class="chips">
                <span class="chip"><?php echo e($student->admission_no); ?></span>
                <?php if($enrollment): ?>
                    <span class="chip"><?php echo e($enrollment->class?->name); ?></span>
                    <span class="chip">Section <?php echo e($enrollment->section?->name ?? '—'); ?></span>
                    <span class="chip">Roll <?php echo e($enrollment->roll_no ?? '—'); ?></span>
                <?php endif; ?>
                <span class="chip"><?php echo e($session?->name ?? 'No session'); ?></span>
                <span class="chip chip-success">Active</span>
            </div>
        </div>
        <div class="chips">
            <a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.profile')); ?>">My profile</a>
        </div>
    </div>

    <div class="metric-grid">
        <div class="card stat"><div class="stat-label">Attendance</div><div class="stat-value"><?php echo e(number_format($attendance['percentage'], 1)); ?>%</div><div class="stat-meta"><?php echo e($attendance['present'] + $attendance['late']); ?> of <?php echo e($attendance['records']); ?> marked days</div></div>
        <div class="card stat"><div class="stat-label">Fees assigned</div><div class="stat-value"><?php echo e(money($fees['total_charged'])); ?></div><div class="stat-meta"><?php echo e($fees['assignments']->count()); ?> fee row(s)</div></div>
        <div class="card stat"><div class="stat-label">Paid</div><div class="stat-value" style="color:var(--success)"><?php echo e(money($fees['total_paid'])); ?></div><div class="stat-meta"><?php echo e($fees['payments']->where('status', 'completed')->count()); ?> completed payment(s)</div></div>
        <div class="card stat"><div class="stat-label">Outstanding</div><div class="stat-value" style="color:<?php echo e($fees['balance'] > 0 ? 'var(--danger)' : 'var(--success)'); ?>"><?php echo e(money($fees['balance'])); ?></div><div class="stat-meta"><?php echo e($fees['overdue'] > 0 ? money($fees['overdue']).' overdue' : 'Nothing overdue'); ?></div></div>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head">
                <div><h2>Published results</h2><p>Only results published by the school appear here.</p></div>
                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.results')); ?>">All results</a>
            </div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Examination</th><th class="num">GPA</th><th>Grade</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="title-cell"><strong><?php echo e($row['exam']->name); ?></strong><span><?php echo e($row['published_at']?->format('d M Y')); ?></span></td>
                                <td class="num mono"><?php echo e(number_format($row['result']['gpa'], 2)); ?></td>
                                <td><?php echo e($row['result']['grade']); ?></td>
                                <td><span class="badge <?php echo e($row['result']['result'] === 'Pass' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e($row['result']['result']); ?></span></td>
                                <td><a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.results.show', $row['exam'])); ?>">Open</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="empty">No published results are available yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Attendance snapshot</h2><p>Recent attendance in the current session.</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.attendance')); ?>">Details</a></div>
            <div class="card-body">
                <div class="progress" aria-label="Attendance percentage"><span style="width: <?php echo e(min(100, $attendance['percentage'])); ?>%"></span></div>
                <div class="chips" style="margin-top:12px">
                    <span class="chip chip-success">Present <?php echo e($attendance['present']); ?></span>
                    <span class="chip chip-danger">Absent <?php echo e($attendance['absent']); ?></span>
                    <span class="chip chip-warning">Late <?php echo e($attendance['late']); ?></span>
                    <span class="chip">Excused <?php echo e($attendance['excused']); ?></span>
                </div>
                <div class="list" style="margin-top:12px">
                    <?php $__empty_1 = true; $__currentLoopData = $attendance['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="list-item">
                            <div><strong><?php echo e($record->attendance_date?->format('d M Y')); ?></strong><small><?php echo e($record->class?->name); ?></small></div>
                            <span class="badge <?php echo e($record->status === 'present' ? 'badge-success' : ($record->status === 'absent' ? 'badge-danger' : 'badge-warning')); ?>"><?php echo e(ucfirst($record->status)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty">No attendance has been marked yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

    <div class="grid grid-2" style="margin-top:18px">
        <section class="card">
            <div class="card-head"><div><h2>Fee ledger</h2><p>Assigned fees, discounts and balances.</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.fees')); ?>">Manage fees</a></div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Fee head</th><th>Period</th><th class="num">Net</th><th class="num">Paid</th><th class="num">Balance</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $fees['assignments']->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->category?->name ?? 'Fee'); ?></td>
                                <td class="mono"><?php echo e($row->period ?? 'One-time'); ?></td>
                                <td class="num mono"><?php echo e(money($row->net_amount)); ?></td>
                                <td class="num mono"><?php echo e(money($row->paid_amount)); ?></td>
                                <td class="num mono"><?php echo e(money($row->balance)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="empty">No fees have been assigned.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Notices</h2><p>Published school announcements.</p></div></div>
            <div class="list">
                <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-item">
                        <div><strong><?php echo e($notice->title); ?></strong><small><?php echo e(Str::limit(strip_tags($notice->body), 90)); ?></small></div>
                        <span class="notice-date"><?php echo e($notice->publish_at?->format('d') ?? $notice->created_at?->format('d')); ?><br><?php echo e($notice->publish_at?->format('M') ?? $notice->created_at?->format('M')); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">No notices have been published.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <div class="grid grid-2" style="margin-top:18px">
        <section class="card">
            <div class="card-head"><div><h2>Upcoming examinations</h2><p>Published exam schedule for your class.</p></div></div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Subject</th><th>Examination</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><?php echo e($paper->subject?->name); ?></td><td><?php echo e($paper->examination?->name); ?></td><td class="mono"><?php echo e($paper->exam_date?->format('d M Y') ?? 'Not scheduled'); ?><?php echo e($paper->start_time ? ' · '.substr($paper->start_time, 0, 5) : ''); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="empty">No published examination schedule is available.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Downloads</h2><p>Files published for students.</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('student.downloads')); ?>">All files</a></div>
            <div class="list">
                <?php $__empty_1 = true; $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-item">
                        <div><strong><?php echo e($download->title); ?></strong><small><?php echo e($download->excerpt ?: $download->category); ?></small></div>
                        <?php if($download->file_url): ?><a class="btn btn-secondary btn-sm" href="<?php echo e($download->file_url); ?>" target="_blank" rel="noopener">Download</a><?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">No files are available.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\student\dashboard.blade.php ENDPATH**/ ?>