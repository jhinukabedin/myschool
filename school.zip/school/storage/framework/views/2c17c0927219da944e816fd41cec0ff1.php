<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'subtitle' => null, 'eyebrow' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'subtitle' => null, 'eyebrow' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="page-header">
    <div>
        <?php if($eyebrow): ?>
            <div class="eyebrow muted-2" style="font-size:10px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;margin-bottom:4px"><?php echo e($eyebrow); ?></div>
        <?php endif; ?>
        <h1 class="page-title"><?php echo e($title); ?></h1>
        <?php if($subtitle): ?><p class="page-subtitle"><?php echo e($subtitle); ?></p><?php endif; ?>
    </div>
    <?php if(isset($actions)): ?>
        <div class="page-actions"><?php echo e($actions); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\components\page-header.blade.php ENDPATH**/ ?>