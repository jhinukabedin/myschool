<?php $__env->startSection('title', 'Guardian Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Parent portal</p>
            <h1>Guardian Profile</h1>
            <p>Your account and the children the school has explicitly linked to it.</p>
        </div>
        <a class="btn btn-secondary" href="<?php echo e(route('parent.dashboard')); ?>">Back to dashboard</a>
    </div>

    <div class="grid grid-2">
        <section class="card">
            <div class="card-head"><div><h2>Account</h2><p>Contact the office to change these details</p></div></div>
            <div class="card-body">
                <div class="grid grid-2">
                    <div><div class="small muted">Name</div><strong><?php echo e($user->name); ?></strong></div>
                    <div><div class="small muted">Login username</div><strong class="mono"><?php echo e($user->username ?? '—'); ?></strong></div>
                    <div><div class="small muted">Email</div><strong><?php echo e($user->email ?? '—'); ?></strong></div>
                    <div><div class="small muted">Mobile</div><strong><?php echo e($user->phone ?? '—'); ?></strong></div>
                    <div><div class="small muted">Last sign-in</div><strong><?php echo e($user->last_login_at?->format('d M Y, h:i A') ?? '—'); ?></strong></div>
                </div>
                <p style="margin-top:16px"><a class="btn btn-secondary" href="<?php echo e(route('password.change')); ?>">Change password</a></p>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><div><h2>Linked children</h2><p>Only these students are visible to your account</p></div></div>
            <div class="list">
                <?php $__empty_1 = true; $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-item">
                        <div>
                            <strong><?php echo e($child->full_name); ?></strong>
                            <small><?php echo e($child->admission_no); ?> · <?php echo e($child->status_label); ?></small>
                            <?php ($latest = $child->enrollments->sortByDesc('academic_session_id')->first()); ?>
                            <?php if($latest): ?>
                                <small><?php echo e($latest->class?->name); ?> · Section <?php echo e($latest->section?->name ?? '—'); ?> · <?php echo e($latest->academicSession?->name); ?></small>
                            <?php endif; ?>
                        </div>
                        <a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.dashboard', ['child' => $child->id])); ?>">Open</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">No children are linked. Ask the school administration for assistance.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>School guardian records</h2><p>Relationship details recorded by the school</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Child</th><th>Relation</th><th>Phone</th><th>Email</th><th>Verified</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($link->student?->full_name); ?></td>
                            <td><?php echo e($link->guardian?->relation ?? $link->relationship ?? '—'); ?></td>
                            <td><?php echo e($link->guardian?->phone ?? '—'); ?></td>
                            <td><?php echo e($link->guardian?->email ?? '—'); ?></td>
                            <td><span class="badge <?php echo e($link->verified_at ? 'badge-success' : 'badge-warning'); ?>"><?php echo e($link->verified_at ? 'Verified' : 'Pending'); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty">No guardian links are available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\parent\profile.blade.php ENDPATH**/ ?>