<?php $__env->startSection('title', 'Parent Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Parent portal</p>
            <h1>Welcome<?php echo e($child ? ', '.$child->first_name.'\'s guardian' : ''); ?></h1>
            <p>Monitor attendance, fees and published results for the children explicitly linked to your account.</p>
        </div>
        <?php if($child): ?>
            <div class="chips">
                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.results.index', $child)); ?>">Results</a>
                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.fees.index', $child)); ?>">Fees</a>
                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.attendance.index', $child)); ?>">Attendance</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if(! $child): ?>
        <div class="card"><div class="empty">
            <strong>No student is linked to this guardian account.</strong><br>
            Ask the school administration to link your account to your child's record. Parent accounts cannot search for students.
        </div></div>
    <?php else: ?>
        <div class="child-select" aria-label="Select child">
            <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('parent.dashboard', ['child' => $childOption->id])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $childOption->id === $child->id]); ?>">
                    <?php echo e($childOption->full_name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="card profile-strip" style="margin-bottom:18px">
            <div class="avatar">
                <?php if($child->photo_url): ?>
                    <img src="<?php echo e($child->photo_url); ?>" alt="<?php echo e($child->full_name); ?>">
                <?php else: ?>
                    <?php echo e(Str::upper(Str::substr($child->first_name, 0, 1).Str::substr($child->last_name, 0, 1))); ?>

                <?php endif; ?>
            </div>
            <div>
                <h2><?php echo e($child->full_name); ?></h2>
                <div class="chips">
                    <span class="chip"><?php echo e($child->admission_no); ?></span>
                    <?php if($enrollment): ?>
                        <span class="chip"><?php echo e($enrollment->class?->name); ?></span>
                        <span class="chip">Section <?php echo e($enrollment->section?->name ?? '—'); ?></span>
                        <span class="chip">Roll <?php echo e($enrollment->roll_no ?? '—'); ?></span>
                    <?php endif; ?>
                    <span class="chip"><?php echo e($session?->name ?? 'No session'); ?></span>
                </div>
            </div>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.profile')); ?>">Guardian profile</a>
        </div>

        <div class="metric-grid">
            <div class="card stat"><div class="stat-label">Attendance</div><div class="stat-value"><?php echo e(number_format($attendance['percentage'], 1)); ?>%</div><div class="stat-meta"><?php echo e($attendance['present'] + $attendance['late']); ?> of <?php echo e($attendance['records']); ?> marked days</div></div>
            <div class="card stat"><div class="stat-label">Fees assigned</div><div class="stat-value"><?php echo e(money($fees['total_charged'])); ?></div><div class="stat-meta"><?php echo e($fees['assignments']->count()); ?> fee row(s)</div></div>
            <div class="card stat"><div class="stat-label">Verified paid</div><div class="stat-value" style="color:var(--success)"><?php echo e(money($fees['total_paid'])); ?></div><div class="stat-meta">School-verified payments</div></div>
            <div class="card stat"><div class="stat-label">Outstanding</div><div class="stat-value" style="color:<?php echo e($fees['balance'] > 0 ? 'var(--danger)' : 'var(--success)'); ?>"><?php echo e(money($fees['balance'])); ?></div><div class="stat-meta"><?php echo e($fees['overdue'] > 0 ? money($fees['overdue']).' overdue' : 'Nothing overdue'); ?></div></div>
        </div>

        <div class="grid grid-2">
            <section class="card">
                <div class="card-head"><div><h2>Published results</h2><p>Latest examinations released by the school</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.results.index', $child)); ?>">All results</a></div>
                <div class="table-wrap">
                    <table class="data">
                        <thead><tr><th>Examination</th><th class="num">GPA</th><th>Grade</th><th>Status</th><th></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="title-cell"><strong><?php echo e($row['exam']->name); ?></strong><span><?php echo e($row['published_at']?->format('d M Y')); ?></span></td>
                                    <td class="num mono"><?php echo e(number_format($row['result']['gpa'], 2)); ?></td>
                                    <td><?php echo e($row['result']['grade']); ?></td>
                                    <td><span class="badge <?php echo e($row['result']['result'] === 'Pass' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e($row['result']['result']); ?></span></td>
                                    <td><a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.results.show', [$child, $row['exam']])); ?>">Open</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="empty">No published results are available.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="card">
                <div class="card-head"><div><h2>Fee balance</h2><p>Current outstanding fee rows</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.fees.index', $child)); ?>">Full ledger</a></div>
                <div class="table-wrap">
                    <table class="data">
                        <thead><tr><th>Fee head</th><th>Due</th><th class="num">Balance</th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $fees['assignments']->where('balance', '>', 0)->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($assignment->category?->name ?? 'Fee'); ?></td>
                                    <td class="mono"><?php echo e($assignment->due_date?->format('d M Y') ?? '—'); ?></td>
                                    <td class="num mono"><?php echo e(money($assignment->balance)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="empty">No outstanding fees.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>

        <div class="grid grid-2" style="margin-top:18px">
            <section class="card">
                <div class="card-head"><div><h2>Recent attendance</h2><p>Last marked days</p></div><a class="btn btn-secondary btn-sm" href="<?php echo e(route('parent.attendance.index', $child)); ?>">Details</a></div>
                <div class="list">
                    <?php $__empty_1 = true; $__currentLoopData = $attendance['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="list-item">
                            <div><strong><?php echo e($record->attendance_date?->format('d M Y')); ?></strong><small><?php echo e($record->class?->name); ?></small></div>
                            <span class="badge <?php echo e($record->status === 'present' ? 'badge-success' : ($record->status === 'absent' ? 'badge-danger' : 'badge-warning')); ?>"><?php echo e(ucfirst($record->status)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty">No attendance has been marked.</div>
                    <?php endif; ?>
                </div>
            </section>

            <section class="card">
                <div class="card-head"><div><h2>Notices</h2><p>School announcements</p></div></div>
                <div class="list">
                    <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="list-item">
                            <div><strong><?php echo e($notice->title); ?></strong><small><?php echo e(Str::limit(strip_tags($notice->body), 100)); ?></small></div>
                            <span class="notice-date"><?php echo e($notice->publish_at?->format('d') ?? $notice->created_at?->format('d')); ?><br><?php echo e($notice->publish_at?->format('M') ?? $notice->created_at?->format('M')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty">No notices have been published.</div>
                    <?php endif; ?>
                </div>
            </section>
        </div>

        <section class="card" style="margin-top:18px">
            <div class="card-head"><div><h2>Examination schedule</h2><p>Published papers for the class</p></div></div>
            <div class="table-wrap">
                <table class="data">
                    <thead><tr><th>Subject</th><th>Examination</th><th>Date</th><th>Time</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($paper->subject?->name); ?></td>
                                <td><?php echo e($paper->examination?->name); ?></td>
                                <td class="mono"><?php echo e($paper->exam_date?->format('d M Y') ?? 'Not scheduled'); ?></td>
                                <td class="mono"><?php echo e($paper->start_time ? substr($paper->start_time, 0, 5) : '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="empty">No published examination schedule is available.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\parent\dashboard.blade.php ENDPATH**/ ?>