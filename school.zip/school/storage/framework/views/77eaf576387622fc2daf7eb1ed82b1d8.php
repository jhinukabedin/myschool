<?php $__env->startSection('title', $notice->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-hero"><div class="container"><div class="breadcrumb">প্রচ্ছদ / নোটিশ</div><h1><?php echo e($notice->title); ?></h1><p><?php echo e($notice->publish_at?->format('d M Y') ?? $notice->created_at?->format('d M Y')); ?></p></div></section>

    <section class="section"><div class="container inner-grid">
        <article class="card article">
            <div style="margin-bottom:12px"><span class="badge green">প্রকাশিত</span></div>
            <div><?php echo nl2br(e($notice->body)); ?></div>
            <hr style="border:0;border-top:1px solid #edf0f4;margin:22px 0">
            <a class="btn btn-outline" href="<?php echo e(route('website.notices')); ?>">← সব নোটিশ</a>
        </article>
        <aside class="stack" style="display:flex;flex-direction:column;gap:14px">
            <div class="card contact-card">
                <h3 style="margin:0 0 10px;color:var(--navy);font-family:'Noto Serif Bengali'">সাম্প্রতিক নোটিশ</h3>
                <?php $__empty_1 = true; $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('website.notice', $item)); ?>" style="display:block;padding:6px 0"><?php echo e($item->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>আর কোনো নোটিশ নেই।</p>
                <?php endif; ?>
            </div>
        </aside>
    </div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\website\notice.blade.php ENDPATH**/ ?>