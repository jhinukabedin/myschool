<?php
    $adminTabs = [
        ['label' => 'Overview', 'route' => 'admin.index', 'active' => 'admin.index', 'can' => 'settings.view'],
        ['label' => 'Sessions', 'route' => 'sessions.index', 'active' => 'sessions.*', 'can' => 'academics.manage'],
        ['label' => 'Classes', 'route' => 'classes.index', 'active' => 'classes.*', 'can' => 'academics.manage'],
        ['label' => 'Sections', 'route' => 'sections.index', 'active' => 'sections.*', 'can' => 'academics.manage'],
        ['label' => 'Users', 'route' => 'users.index', 'active' => 'users.*', 'can' => 'users.manage'],
        ['label' => 'Roles', 'route' => 'roles.index', 'active' => 'roles.*', 'can' => 'users.manage'],
        ['label' => 'Portal Accounts', 'route' => 'portal-accounts.index', 'active' => 'portal-accounts.*', 'can' => 'portals.manage'],
        ['label' => 'Audit Log', 'route' => 'audit.index', 'active' => 'audit.*', 'can' => 'audit.view'],
        ['label' => 'Website', 'route' => 'website-admin.index', 'active' => 'website-admin.*|website-content.*', 'can' => 'website.view'],
        ['label' => 'Messages', 'route' => 'messages.index', 'active' => 'messages.*', 'can' => 'website.view'],
        ['label' => 'Settings', 'route' => 'settings.index', 'active' => 'settings.*', 'can' => 'settings.view'],
    ];
?>

<div class="tabs" style="margin-bottom:16px;border:1px solid var(--line);border-radius:12px;background:var(--surface)">
    <?php $__currentLoopData = $adminTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($tab['can'])): ?>
            <a href="<?php echo e(route($tab['route'])); ?>" class="tab <?php echo e(request()->routeIs($tab['active']) ? 'active' : ''); ?>"><?php echo e($tab['label']); ?></a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\admin\_nav.blade.php ENDPATH**/ ?>