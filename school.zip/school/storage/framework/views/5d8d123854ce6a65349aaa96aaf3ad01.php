<?php $__env->startSection('title', 'Fees & Payments'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div>
            <p class="eyebrow">Fee ledger</p>
            <h1><?php echo e($portalRole === 'parent' ? $student->full_name.'\'s Fees' : 'Fees & Payments'); ?></h1>
            <p>Assigned fees, verified manual payments, discounts and outstanding balances for <?php echo e($session?->name ?? 'the current session'); ?>.</p>
        </div>
        <?php if(isset($children) && $children->count() > 1): ?>
            <div class="selector-form">
                <div class="field">
                    <label for="child-switch">Child</label>
                    <select id="child-switch" onchange="if(this.value) window.location.href=this.value">
                        <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(route('parent.fees.index', $childOption)); ?>" <?php if($childOption->id === $student->id): echo 'selected'; endif; ?>><?php echo e($childOption->full_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="metric-grid">
        <div class="card stat"><div class="stat-label">Net assigned</div><div class="stat-value"><?php echo e(money($fees['total_charged'])); ?></div><div class="stat-meta">After discounts and waivers</div></div>
        <div class="card stat"><div class="stat-label">Verified paid</div><div class="stat-value" style="color:var(--success)"><?php echo e(money($fees['total_paid'])); ?></div><div class="stat-meta">Completed payments only</div></div>
        <div class="card stat"><div class="stat-label">Balance</div><div class="stat-value" style="color:<?php echo e($fees['balance'] > 0 ? 'var(--danger)' : 'var(--success)'); ?>"><?php echo e(money($fees['balance'])); ?></div><div class="stat-meta">Across all assignments</div></div>
        <div class="card stat"><div class="stat-label">Overdue</div><div class="stat-value"><?php echo e(money($fees['overdue'])); ?></div><div class="stat-meta">Past the due date</div></div>
    </div>

    <div class="hero-note" style="margin-bottom:18px">
        Online payment is not enabled on this portal. A payment is only counted after the school office records and verifies it. Reversed payments are excluded from the balance.
    </div>

    <section class="card">
        <div class="card-head"><div><h2>Fee assignments</h2><p>Every fee head applied to the student record</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Fee head</th><th>Period</th><th>Due date</th><th class="num">Gross</th><th class="num">Discount / waiver</th><th class="num">Net</th><th class="num">Paid</th><th class="num">Balance</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $fees['assignments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="title-cell"><strong><?php echo e($assignment->category?->name ?? 'Fee'); ?></strong><span><?php echo e($assignment->note); ?></span></td>
                            <td class="mono"><?php echo e($assignment->period ?? 'One-time'); ?></td>
                            <td class="mono"><?php echo e($assignment->due_date?->format('d M Y') ?? '—'); ?></td>
                            <td class="num mono"><?php echo e(money($assignment->amount)); ?></td>
                            <td class="num mono"><?php echo e(money((float) $assignment->discount_amount + (float) $assignment->waiver_amount)); ?></td>
                            <td class="num mono"><?php echo e(money($assignment->net_amount)); ?></td>
                            <td class="num mono"><?php echo e(money($assignment->paid_amount)); ?></td>
                            <td class="num mono"><?php echo e(money($assignment->balance)); ?></td>
                            <td>
                                <?php if($assignment->balance <= 0): ?>
                                    <span class="badge badge-success">Paid</span>
                                <?php elseif($assignment->due_date && $assignment->due_date->isPast()): ?>
                                    <span class="badge badge-danger">Overdue</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Due</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9" class="empty">No fees have been assigned for this session.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="card" style="margin-top:18px">
        <div class="card-head"><div><h2>Payment history</h2><p>Receipts issued by the school. Reversed payments remain visible for audit.</p></div></div>
        <div class="table-wrap">
            <table class="data">
                <thead><tr><th>Receipt</th><th>Paid at</th><th>Method</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $fees['payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $receiptUrl = $portalRole === 'parent'
                                ? route($receiptRoute, [$student, $payment])
                                : route($receiptRoute, $payment);
                        ?>
                        <tr>
                            <td class="mono"><?php echo e($payment->receipt_no); ?></td>
                            <td class="mono"><?php echo e($payment->paid_at?->format('d M Y, h:i A')); ?></td>
                            <td><?php echo e(ucfirst(str_replace('_', ' ', $payment->payment_method ?? '—'))); ?><?php echo e($payment->reference_no ? ' · '.$payment->reference_no : ''); ?></td>
                            <td class="num mono"><?php echo e(money($payment->amount)); ?></td>
                            <td>
                                <span class="badge <?php echo e($payment->status === 'completed' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e(ucfirst($payment->status)); ?></span>
                                <?php if($payment->status === 'reversed' && $payment->reversals->isNotEmpty()): ?>
                                    <div class="small muted"><?php echo e($payment->reversals->first()->reason); ?></div>
                                <?php endif; ?>
                            </td>
                            <td><a class="btn btn-secondary btn-sm" href="<?php echo e($receiptUrl); ?>">Receipt</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="empty">No payments have been recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\portal\fees\index.blade.php ENDPATH**/ ?>