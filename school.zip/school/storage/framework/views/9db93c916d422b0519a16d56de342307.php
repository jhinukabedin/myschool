<?php
    $websiteTabs = [
        ['label' => 'Dashboard', 'route' => 'website-admin.index', 'active' => 'website-admin.index', 'can' => 'website.view'],
        ['label' => 'Slider', 'route' => 'website-admin.slider', 'active' => 'website-admin.slider', 'can' => 'website.view'],
        ['label' => 'Introduction', 'route' => 'website-admin.introduction', 'active' => 'website-admin.introduction', 'can' => 'website.view'],
        ['label' => 'Administration', 'route' => 'website-admin.administration-message', 'active' => 'website-admin.administration-message', 'can' => 'website.view'],
        ['label' => 'Principal', 'route' => 'website-admin.principal-message', 'active' => 'website-admin.principal-message', 'can' => 'website.view'],
        ['label' => 'President', 'route' => 'website-admin.president-message', 'active' => 'website-admin.president-message', 'can' => 'website.view'],
        ['label' => 'Academic corner', 'route' => 'website-admin.academic-corner', 'active' => 'website-admin.academic-corner', 'can' => 'website.view'],
        ['label' => 'News', 'route' => 'website-admin.news', 'active' => 'website-admin.news', 'can' => 'website.view'],
        ['label' => 'Events', 'route' => 'website-admin.events', 'active' => 'website-admin.events', 'can' => 'website.view'],
        ['label' => 'Gallery', 'route' => 'website-admin.gallery', 'active' => 'website-admin.gallery', 'can' => 'website.view'],
        ['label' => 'Pages', 'route' => 'website-admin.pages', 'active' => 'website-admin.pages', 'can' => 'website.view'],
        ['label' => 'Downloads', 'route' => 'website-admin.downloads', 'active' => 'website-admin.downloads', 'can' => 'website.view'],
        ['label' => 'Faculty', 'route' => 'website-admin.faculty', 'active' => 'website-admin.faculty', 'can' => 'website.view'],
        ['label' => 'Content library', 'route' => 'website-content.index', 'active' => 'website-content.*', 'can' => 'website.view'],
        ['label' => 'Design & logo', 'route' => 'website-admin.design', 'active' => 'website-admin.design', 'can' => 'website.manage'],
        ['label' => 'Menus', 'route' => 'website-menus.index', 'active' => 'website-menus.*', 'can' => 'website.menus'],
        ['label' => 'Media', 'route' => 'media.index', 'active' => 'media.*', 'can' => 'website.media'],
        ['label' => 'Messages', 'route' => 'messages.index', 'active' => 'messages.*', 'can' => 'website.view'],
    ];
?>

<div class="tab-bar" style="display:flex;gap:4px;flex-wrap:wrap;margin:0 0 16px;border-bottom:1px solid var(--border);padding-bottom:0">
    <?php $__currentLoopData = $websiteTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($tab['can'])): ?>
            <?php $active = $tab['active'] && request()->routeIs($tab['active']); ?>
            <a href="<?php echo e(route($tab['route'])); ?>" class="btn btn-ghost btn-sm <?php echo e($active ? 'active' : ''); ?>"
               style="<?php echo e($active ? 'border-color:var(--border);background:#fff;border-bottom-color:#fff;border-radius:8px 8px 0 0;margin-bottom:-1px' : 'border-color:transparent'); ?>">
                <?php echo e($tab['label']); ?>

            </a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Jhinuk\BHServe\www\school\resources\views\admin\website\_nav.blade.php ENDPATH**/ ?>