<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class WebsiteContent extends Model
{
    use HasFactory;

    public const TYPES = [
        'page' => 'Page',
        'news' => 'News',
        'event' => 'Event',
        'gallery' => 'Gallery item',
        'download' => 'Download',
        'faculty' => 'Faculty profile',
        'slider' => 'Homepage slider',
        'introduction' => 'Institution introduction',
        'administration_message' => 'Administration message',
        'principal_message' => 'Principal message',
        'president_message' => 'President message',
        'academic' => 'Academic corner item',
    ];

    /**
     * Sections that are expected to have one published record. Pages, slider
     * items, academic cards, news and gallery items remain repeatable.
     */
    public const SINGLETON_TYPES = [
        'introduction', 'administration_message', 'principal_message', 'president_message',
    ];

    protected $fillable = [
        'type', 'title', 'slug', 'excerpt', 'body', 'body_format', 'image_path', 'file_path',
        'link_url', 'button_label',
        'category', 'is_featured', 'sort_order', 'status', 'published_at', 'created_by',
        'template', 'meta_title', 'meta_description', 'og_image_path',
        'published_by', 'updated_by', 'archived_at',
    ];

    protected function casts(): array
    {
        return [
            'is_featured' => 'boolean',
            'published_at' => 'datetime',
            'archived_at' => 'datetime',
        ];
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function editor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function publisher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'published_by');
    }

    public function revisions(): HasMany
    {
        return $this->hasMany(WebsiteContentRevision::class)->latest('created_at');
    }

    public function scopePubliclyVisible(Builder $query): Builder
    {
        return $query->where('status', 'published')
            ->where(fn ($q) => $q->whereNull('published_at')->orWhere('published_at', '<=', now()));
    }

    public function scopeOfType(Builder $query, string $type): Builder
    {
        return $query->where('type', $type);
    }

    public function getImageUrlAttribute(): ?string
    {
        return $this->image_path ? asset('storage/'.$this->image_path) : null;
    }

    /**
     * Content saved before the rich text editor was introduced remains plain
     * text and is escaped. Sanitized HTML is only rendered for html records.
     */
    public function getBodyHtmlAttribute(): string
    {
        if (($this->body_format ?? 'text') === 'html') {
            return (string) $this->body;
        }

        return nl2br(e((string) $this->body));
    }

    public function getOgImageUrlAttribute(): ?string
    {
        return $this->og_image_path ? asset('storage/'.$this->og_image_path) : $this->image_url;
    }

    public function getPublicUrlAttribute(): ?string
    {
        return match ($this->type) {
            'news' => route('website.news.item', $this->slug),
            'page' => route('website.page', $this->slug),
            default => null,
        };
    }

    /**
     * Store the version that existed before an update. Revisions are immutable.
     */
    public function captureRevision(?int $userId = null, ?string $reason = null): WebsiteContentRevision
    {
        return $this->revisions()->create([
            'user_id' => $userId,
            'reason' => $reason,
            'payload' => $this->only([
                'type', 'title', 'slug', 'excerpt', 'body', 'body_format', 'image_path', 'file_path',
                'link_url', 'button_label',
                'category', 'is_featured', 'sort_order', 'status', 'published_at',
                'template', 'meta_title', 'meta_description', 'og_image_path',
            ]),
        ]);
    }

    public function getFileUrlAttribute(): ?string
    {
        return $this->file_path ? asset('storage/'.$this->file_path) : null;
    }

    public static function uniqueSlug(string $title, ?int $ignoreId = null): string
    {
        $base = Str::slug($title) ?: 'item';
        $slug = $base;
        $i = 2;

        while (static::query()->where('slug', $slug)->when($ignoreId, fn ($q) => $q->whereKeyNot($ignoreId))->exists()) {
            $slug = $base.'-'.$i++;
        }

        return $slug;
    }
}
