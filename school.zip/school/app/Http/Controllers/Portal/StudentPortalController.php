<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Models\Examination;
use App\Models\Payment;
use App\Models\Student;
use App\Services\PortalService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class StudentPortalController extends Controller
{
    public function __construct(private readonly PortalService $portal) {}

    public function dashboard(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());
        $session = current_session();
        $enrollment = $this->portal->enrollment($student, $session);
        $fees = $this->portal->fees($student, $session);

        return view('portal.student.dashboard', [
            'student' => $student,
            'session' => $session,
            'enrollment' => $enrollment,
            'attendance' => $this->portal->attendance($student, $session),
            'results' => $this->portal->publishedResults($student, $session)->take(3),
            'fees' => $fees,
            'exams' => $this->portal->examSchedule($student, $session)->take(5),
            'notices' => $this->portal->notices($student, $session)->take(5),
            'downloads' => $this->portal->downloads()->take(4),
        ]);
    }

    public function profile(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());

        return view('portal.student.profile', [
            'student' => $student->load(['guardians', 'enrollments.class', 'enrollments.section', 'enrollments.academicSession']),
            'session' => current_session(),
        ]);
    }

    public function results(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());
        $session = current_session();

        return view('portal.results.index', [
            'student' => $student,
            'session' => $session,
            'results' => $this->portal->publishedResults($student, $session),
            'portalPrefix' => 'student',
            'enrollment' => $this->portal->enrollment($student, $session),
        ]);
    }

    public function resultSheet(Request $request, Examination $exam): View
    {
        $student = $this->portal->studentFor($request->user());
        $payload = $this->publishedResult($exam, $student->id, $student);

        return view('portal.results.sheet', $payload + [
            'backUrl' => route('student.results'),
            'portalRole' => 'Student',
        ]);
    }

    public function fees(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());
        $session = current_session();

        return view('portal.fees.index', [
            'student' => $student,
            'session' => $session,
            'fees' => $this->portal->fees($student, $session),
            'portalRole' => 'student',
            'receiptRoute' => 'student.payments.receipt',
        ]);
    }

    public function receipt(Request $request, Payment $payment): View
    {
        $student = $this->portal->studentFor($request->user());
        $payment = $this->portal->paymentForStudent($student, $payment);

        return view('fees.receipt', [
            'payment' => $payment,
            'backUrl' => route('student.fees'),
        ]);
    }

    public function attendance(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());
        $session = current_session();

        return view('portal.attendance.index', [
            'student' => $student,
            'session' => $session,
            'attendance' => $this->portal->attendance($student, $session),
            'enrollment' => $this->portal->enrollment($student, $session),
            'portalRole' => 'student',
        ]);
    }

    public function downloads(Request $request): View
    {
        $student = $this->portal->studentFor($request->user());

        return view('portal.downloads', [
            'student' => $student,
            'downloads' => $this->portal->downloads(),
            'portalRole' => 'student',
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function publishedResult(Examination $exam, int $studentId, Student $student): array
    {
        abort_unless(
            $exam->status === 'published'
            && $exam->result_published_at !== null
            && $exam->resultSnapshots()->where('student_id', $studentId)->exists(),
            404
        );

        $payload = $this->portal->result($exam, $student);
        abort_unless($payload, 404);

        return $payload;
    }
}
