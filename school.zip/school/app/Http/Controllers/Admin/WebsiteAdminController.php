<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactMessage;
use App\Models\Media;
use App\Models\SchoolSetting;
use App\Models\WebsiteContent;
use App\Models\WebsiteMenu;
use App\Services\AuditLogService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class WebsiteAdminController extends Controller
{
    /**
     * Defaults are kept here as well as in the seeder so existing databases
     * receive sensible values without rewriting configured settings.
     */
    public const DEFAULTS = [
        'website_name_bn' => 'আদর্শ উচ্চ বিদ্যালয়',
        'website_name_en' => 'ADARSHA HIGH SCHOOL',
        'website_tagline' => 'শিক্ষা • শৃঙ্খলা • নৈতিকতা • আধুনিকতা',
        'website_logo_mark' => 'HS',
        'website_topbar_text' => 'শিক্ষা • শৃঙ্খলা • নৈতিকতা • আধুনিকতা',
        'website_header_cta_label' => 'ভর্তি আবেদন',
        'website_header_cta_url' => '/admission/apply',
        'website_footer_about' => 'শিক্ষার্থীদের জ্ঞান, নৈতিকতা ও মানবিক মূল্যবোধে গড়ে তোলার অঙ্গীকার।',
        'website_footer_copyright' => '© :year আদর্শ উচ্চ বিদ্যালয় • সর্বস্বত্ব সংরক্ষিত',
        'website_footer_note' => 'সাইটটি বিদ্যালয়ের অফিস কর্তৃক পরিচালিত।',
        'website_header_style' => 'classic',
        'website_footer_style' => 'classic',
        'website_theme' => 'navy',
        'website_show_topbar' => '1',
        'website_facebook' => '',
        'website_x' => '',
        'website_youtube' => '',
    ];

    public const HEADER_STYLES = [
        'classic' => 'Classic blue',
        'centered' => 'Centered crest',
        'split' => 'Split banner',
        'minimal' => 'Minimal compact',
    ];

    public const FOOTER_STYLES = [
        'classic' => 'Classic four columns',
        'columns' => 'Wide columns',
        'compact' => 'Compact bar',
        'accent' => 'Accent panel',
    ];

    public const THEMES = [
        'navy' => 'Navy & gold',
        'emerald' => 'Emerald & sand',
        'maroon' => 'Maroon & cream',
        'royal' => 'Royal purple',
    ];

    public function __construct(private readonly AuditLogService $audit) {}

    public function index(): View
    {
        $counts = WebsiteContent::query()
            ->selectRaw('type, COUNT(*) as total')
            ->groupBy('type')
            ->pluck('total', 'type');

        return view('admin.website.dashboard', [
            'counts' => $counts,
            'sections' => WebsiteContentController::SECTIONS,
            'published' => WebsiteContent::query()->where('status', 'published')->count(),
            'draft' => WebsiteContent::query()->where('status', 'draft')->count(),
            'latest' => WebsiteContent::query()->with('creator')->latest('updated_at')->limit(8)->get(),
            'newMessages' => ContactMessage::query()->where('status', 'new')->count(),
            'hasHeaderMenu' => WebsiteMenu::query()->where('location', 'header')->exists(),
            'hasFooterMenu' => WebsiteMenu::query()->where('location', 'footer')->exists(),
        ]);
    }

    public function design(): View
    {
        $settings = [];

        foreach (self::DEFAULTS as $key => $default) {
            $settings[$key] = school_setting($key, $default);
        }

        return view('admin.website.design', [
            'settings' => $settings,
            'logoPath' => school_setting('website_logo_path'),
            'logoUrl' => school_setting('website_logo_path') ? asset('storage/'.school_setting('website_logo_path')) : null,
            'headerStyles' => self::HEADER_STYLES,
            'footerStyles' => self::FOOTER_STYLES,
            'themes' => self::THEMES,
        ]);
    }

    public function updateDesign(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'website_name_bn' => ['required', 'string', 'max:150'],
            'website_name_en' => ['required', 'string', 'max:150'],
            'website_tagline' => ['nullable', 'string', 'max:200'],
            'website_logo_mark' => ['nullable', 'string', 'max:4'],
            'website_topbar_text' => ['nullable', 'string', 'max:180'],
            'website_header_cta_label' => ['nullable', 'string', 'max:60'],
            'website_header_cta_url' => ['nullable', 'string', 'max:500', function (string $attribute, mixed $value, \Closure $fail) {
                if (filled($value) && ! preg_match('#^(https?://|mailto:|tel:|/(?!/)|\#)#i', (string) $value)) {
                    $fail('The header button link must be a relative path or an http(s), mailto or tel URL.');
                }
            }],
            'website_footer_about' => ['nullable', 'string', 'max:500'],
            'website_footer_copyright' => ['nullable', 'string', 'max:200'],
            'website_footer_note' => ['nullable', 'string', 'max:200'],
            'website_facebook' => ['nullable', 'url', 'max:255'],
            'website_x' => ['nullable', 'url', 'max:255'],
            'website_youtube' => ['nullable', 'url', 'max:255'],
            'website_header_style' => ['required', Rule::in(array_keys(self::HEADER_STYLES))],
            'website_footer_style' => ['required', Rule::in(array_keys(self::FOOTER_STYLES))],
            'website_theme' => ['required', Rule::in(array_keys(self::THEMES))],
            'website_show_topbar' => ['nullable', 'boolean'],
            'logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'remove_logo' => ['nullable', 'boolean'],
        ]);

        $logo = $request->file('logo');
        $removeLogo = $request->boolean('remove_logo');
        unset($data['logo'], $data['remove_logo']);

        $before = collect(array_keys(self::DEFAULTS))
            ->mapWithKeys(fn (string $key) => [$key => school_setting($key)])
            ->all();

        $oldLogo = school_setting('website_logo_path');

        if ($logo) {
            $data['website_logo_path'] = $logo->store('website/logo', 'public');

            if ($oldLogo && $oldLogo !== $data['website_logo_path']) {
                $this->deleteLogoIfUnused($oldLogo);
            }
        } elseif ($removeLogo && $oldLogo) {
            $data['website_logo_path'] = null;
            $this->deleteLogoIfUnused($oldLogo);
        }

        $data['website_show_topbar'] = $request->boolean('website_show_topbar') ? '1' : '0';

        foreach ($data as $key => $value) {
            SchoolSetting::put($key, $value, 'website');
        }

        $this->audit->record(
            'website_design_updated',
            'Website',
            'Website design, logo, header and footer settings updated',
            null,
            $before,
            collect(array_keys(self::DEFAULTS))->mapWithKeys(fn (string $key) => [$key => school_setting($key)])->all()
                + ['logo_changed' => (bool) $logo, 'logo_removed' => $removeLogo]
        );

        return back()->with('success', 'Website design saved. The public site now uses the selected header, footer, logo and content text.');
    }

    private function deleteLogoIfUnused(string $path): void
    {
        $usedByContent = WebsiteContent::query()
            ->where(fn ($query) => $query->where('image_path', $path)->orWhere('og_image_path', $path))
            ->exists();
        $usedByMedia = Media::query()->where('path', $path)->exists();

        if (! $usedByContent && ! $usedByMedia) {
            Storage::disk('public')->delete($path);
        }
    }
}
